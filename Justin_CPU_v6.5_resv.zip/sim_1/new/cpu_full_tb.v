`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// 综合整机测试（cpu_full_tb）：一个 tb 覆盖此前分散的 uart_rx_tb /
// uart_poll_tb / uart_loop_tb / single_cpu_top_tb 的测点。
// 配套 ins_rom.hex = 综合大程序，一次跑完：
//   段1 算术/逻辑自检（写 r1..r11）→ 段2 调用返回（写 r12/r13/r14）
//   段3 UART 收发循环（收字节 → XORI 0x20 → 回发）
// tb 检查：
//   ① r1..r14 期望值（段1/段2，8us 后寄存器已定）
//   ② 发 'a'(0x61) → 期望回发 'A'(0x41)
//   ③ 发 'B'(0x42) → 期望回发 'b'(0x62)
// 运行：cd project_self-try.srcs && /d/iverilog/bin/iverilog -g2012 -o cpu_full_sim \
//          sources_1/new/*.v sim_1/new/cpu_full_tb.v && /d/iverilog/bin/vvp cpu_full_sim
//////////////////////////////////////////////////////////////////////////////////

module cpu_full_tb;

    reg clk = 0, rst = 1, rx = 1;
    wire tx;

    single_cpu_top u_top(
        .clk(clk),
        .rst(rst),
        .rx(rx),
        .tx(tx)
    );

    always #10 clk = ~clk;   // 50MHz

    localparam MCNT = 434;   // 115200 @ 50MHz 每 bit 拍数

    integer errors = 0;

    // ===== CPU tx 接收模型（捕获 CPU 回发的帧）=====
    reg tx_d = 1;
    reg rxing = 0;
    reg [15:0] s_cnt = 0;
    reg [3:0]  nbit = 0;
    reg [7:0]  rbyte = 0;
    reg [7:0]  got [0:15];
    reg [3:0]  got_cnt = 0;

    always @(posedge clk) begin
        tx_d <= tx;
        if (rxing) begin
            s_cnt <= s_cnt + 1;
            if (s_cnt == MCNT/2 - 1 + nbit * MCNT) begin
                if (nbit == 0) begin
                    if (tx !== 1'b0) $display("FAIL: tx 起始位非 0");
                    nbit <= nbit + 1;
                end
                else if (nbit <= 8) begin
                    rbyte[nbit - 1] <= tx;
                    nbit <= nbit + 1;
                end
                else begin
                    if (tx !== 1'b1) $display("FAIL: tx 停止位非 1");
                    got[got_cnt] <= rbyte;
                    got_cnt <= got_cnt + 1;
                    rxing <= 0;
                    $display("CPU TX @%0t  0x%02x  (%c)", $time, rbyte, rbyte);
                end
            end
        end
        else if (tx_d && !tx) begin
            rxing <= 1; s_cnt <= 0; nbit <= 0; rbyte <= 0;
        end
    end

    // ===== tb 往 rx 发帧 =====
    task sbit(input v);
        begin rx = v; #(MCNT * 20); end
    endtask
    task sbyte(input [7:0] v);
        integer i;
        begin
            sbit(1'b0);
            for (i = 0; i < 8; i = i + 1) sbit(v[i]);
            sbit(1'b1);
        end
    endtask

    // ===== 载入指令 =====
    initial begin
        $readmemh("E:/Vivado_Projects/project_self-try/project_self-try.srcs/ins_rom.hex", u_top.u_ins_rom.mem);
    end

    // ===== 复位 =====
    initial begin
        rst = 1;
        #20
        rst = 0;
    end

    // ===== 寄存器检查 =====
    task checkr(input [7:0] idx, input [7:0] exp);
        begin
            if (u_top.u_reg_f.regs[idx] !== exp) begin
                $display("FAIL r%0d = 0x%02x (期望 0x%02x)", idx, u_top.u_reg_f.regs[idx], exp);
                errors = errors + 1;
            end
            else
                $display("OK   r%0d = 0x%02x", idx, u_top.u_reg_f.regs[idx]);
        end
    endtask

    // ===== 主流程 =====
    initial begin
        // 段1/段2 执行完进段3 循环后，r1..r14 定值不再变
        #8000;
        $display("---- 段1 算术/逻辑自检 ----");
        checkr(8'd1,  8'h41);   // ADDI
        checkr(8'd2,  8'h42);   // ADDI（前送依赖）
        checkr(8'd3,  8'h3A);   // SUBI
        checkr(8'd4,  8'h0F);   // ADDI
        checkr(8'd5,  8'h0A);   // ANDI
        checkr(8'd6,  8'h3A);   // ORI
        checkr(8'd7,  8'h22);   // XORI
        checkr(8'd8,  8'h78);   // SLLI
        checkr(8'd9,  8'h1E);   // SRLI
        checkr(8'd10, 8'h01);   // SLTIU
        checkr(8'd11, 8'h00);   // SLTU
        $display("---- 段2 调用返回 ----");
        checkr(8'd12, 8'h24);   // 子程序内
        checkr(8'd13, 8'h27);   // 子程序内
        checkr(8'd14, 8'hAA);   // JALR 返回后

        // ---- 段3 UART 收发 ----
        $display("---- 段3 UART 回环（XORI 0x20 翻转大小写）----");
        $display("TB: 发送 'a' (0x61)，期望回 'A' (0x41)");
        sbyte(8'h61);
        while (got_cnt < 1) #1000;
        if (got[0] !== 8'h41) begin
            $display("FAIL 回发[0] = 0x%02x (期望 0x41)", got[0]);
            errors = errors + 1;
        end

        $display("TB: 发送 'B' (0x42)，期望回 'b' (0x62)");
        sbyte(8'h42);
        while (got_cnt < 2) #1000;
        if (got[1] !== 8'h62) begin
            $display("FAIL 回发[1] = 0x%02x (期望 0x62)", got[1]);
            errors = errors + 1;
        end

        // ---- 汇总 ----
        if (errors == 0)
            $display("===== ALL TESTS PASSED (%0d bytes received) =====", got_cnt);
        else
            $display("===== FAIL: %0d error(s) =====", errors);
        $finish;
    end

    // 兜底：死等保护
    initial begin
        #600000;
        $display("===== TIMEOUT =====");
        $finish;
    end

endmodule
