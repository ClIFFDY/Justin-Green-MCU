`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/14 04:14:50
// Design Name: 
// Module Name: single_mcu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module single_mcu_top(
    input wire rst_n,
    input wire clk,
    output wire tx,
    input wire rx
    );

    wire rst = ~rst_n;  

    wire [15:0] bus_addr_f;
    wire [7:0] bus_data_f;
    wire [3:0] bus_sig_f;
    reg [7:0] bus_data_b;
    wire [1:0] uart_sig_line;
    wire stall_bus;

    wire [7:0] bus_data_uart;
    wire [7:0] bus_data_ram;

    always @(*) begin
        case (bus_addr_f[15:13])
        3'b001: bus_data_b = bus_data_ram;
        3'b010: bus_data_b = bus_data_uart;
        default: bus_data_b = 8'b0;
        endcase
    end

    single_cpu_top u_cpu(
        .clk(clk),
        .rst(rst),
        .bus_data_in(bus_data_b),
        .uart_sig_in(uart_sig_line),
        .stall_bus(stall_bus),
        //
        .bus_addr_out(bus_addr_f),
        .bus_data_out(bus_data_f),
        .bus_sig_out(bus_sig_f)
    );

    uart_top u_uart(
        .clk(clk),
        .rst(rst),
        .rx(rx),
        .bus_addr_in(bus_addr_f),   
        .bus_data_in(bus_data_f),
        .bus_sig_in(bus_sig_f),
        //
        .tx(tx),
        .bus_data_out(bus_data_uart),
        .uart_sig_out(uart_sig_line)
    );

    data_ram u_data_ram(
        .clk(clk),
        .bus_addr_in(bus_addr_f),
        .bus_data_in(bus_data_f),
        .bus_sig_in(bus_sig_f),
        //
        .bus_data_out(bus_data_ram),
        .stall_bus(stall_bus)
    );

endmodule
