`timescale 1ns / 1ps
module ram_test_tb;
    reg clk = 0, rst_n = 1, rx = 1;
    wire tx;
    single_soc_top u_top(.clk(clk), .rst_n(rst_n), .rx(rx), .tx(tx));
    always #10 clk = ~clk;

    initial begin
        $readmemh("E:/tmp/ram_loopback.hex", u_top.u_cpu.u_ins_rom.mem);
        rst_n = 0; #20 rst_n = 1;
    end

    integer errors = 0;
    task checkr(input [7:0] idx, input [7:0] exp);
        begin
            if (u_top.u_cpu.u_reg_f.regs[idx] !== exp) begin
                $display("FAIL r%0d = 0x%02x (期望 0x%02x)", idx, u_top.u_cpu.u_reg_f.regs[idx], exp);
                errors = errors + 1;
            end
            else $display("OK   r%0d = 0x%02x", idx, u_top.u_cpu.u_reg_f.regs[idx]);
        end
    endtask

    initial begin
        #600;
        $display("---- RAM 回写/读回 ----");
        checkr(8'd1, 8'h5A);   // 写源值
        checkr(8'd2, 8'h5A);   // 读回值（关键）
        checkr(8'd3, 8'h5B);   // 读回+1
        if (errors == 0) $display("===== RAM TEST PASSED =====");
        else $display("===== RAM TEST FAIL: %0d error(s) =====", errors);
        $finish;
    end

    initial begin
        #20000;
        $display("===== TIMEOUT =====");
        $finish;
    end
endmodule
