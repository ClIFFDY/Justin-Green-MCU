`timescale 1ns / 1ps
// 复位测试：运行中/（可能 stall 中）多次拉低 rst_n，验证
//   1) 复位期间 pc=0、CPU 停
//   2) 释放后从 0 重跑（r14 计数 +1）、r1/r2 重新算对
module ram_rst_tb;
    reg clk = 0, rst_n = 1, rx = 1;
    wire tx;
    single_soc_top u_top(.clk(clk), .rst_n(rst_n), .rx(rx), .tx(tx));
    always #10 clk = ~clk;

    initial begin
        $readmemh("E:/tmp/ram_rst.hex", u_top.u_cpu.u_ins_rom.mem);
        rst_n = 0; #20 rst_n = 1;
    end

    integer errors = 0;
    task checkr(input [7:0] idx, input [7:0] exp);
        begin
            if (u_top.u_cpu.u_reg_f.regs[idx] !== exp) begin
                $display("FAIL r%0d = 0x%02x (期望 0x%02x)", idx, u_top.u_cpu.u_reg_f.regs[idx], exp);
                errors = errors + 1;
            end
            else $display("OK   r%0d = 0x%02x", idx, u_top.u_cpu.u_reg_f.regs[idx]);
        end
    endtask

    task doreset(input t);
        begin
            #t;
            $display("---- 拉低 rst_n @%0t ----", $time);
            rst_n = 0;
            #(50);   // 5 拍
            if (u_top.u_cpu.u_pc.pc_addr !== 8'h00)
                $display("FAIL 复位期间 pc=%0h (期望 0)", u_top.u_cpu.u_pc.pc_addr);
            else
                $display("OK   复位期间 pc=0");
            rst_n = 1;
        end
    endtask

    initial begin
        #500;
        $display("---- 第一次运行后 ----");
        checkr(8'd1, 8'h5A);
        checkr(8'd2, 8'h5A);
        checkr(8'd14, 8'h01);

        doreset(100);         // t=600 复位
        #700;                 // 等到 t=1300，二次运行完
        $display("---- 第二次运行后 ----");
        checkr(8'd1, 8'h5A);
        checkr(8'd2, 8'h5A);
        checkr(8'd14, 8'h02);

        doreset(100);         // t=1400 复位
        #700;                 // t=2100 三次运行完
        $display("---- 第三次运行后 ----");
        checkr(8'd1, 8'h5A);
        checkr(8'd2, 8'h5A);
        checkr(8'd14, 8'h03);

        if (errors == 0) $display("===== RST TEST PASSED =====");
        else $display("===== RST TEST FAIL: %0d error(s) =====", errors);
        $finish;
    end

    initial begin
        #30000;
        $display("===== TIMEOUT =====");
        $finish;
    end
endmodule
