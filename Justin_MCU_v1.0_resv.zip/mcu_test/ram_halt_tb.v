`timescale 1ns / 1ps
// stall/halt 优先级测试 tb：
//   - r1/r2 确认 RAM 通路（含 stall）正常
//   - r3/r4 揭示 HALT 后执行情况
//   - pc 双采样判断 CPU 是停住还是仍在跑
module ram_halt_tb;
    reg clk = 0, rst_n = 1, rx = 1;
    wire tx;
    single_soc_top u_top(.clk(clk), .rst_n(rst_n), .rx(rx), .tx(tx));
    always #10 clk = ~clk;

    initial begin
        $readmemh("E:/tmp/ram_halt.hex", u_top.u_cpu.u_ins_rom.mem);
        rst_n = 0; #20 rst_n = 1;
    end

    integer errors = 0;
    task checkr(input [7:0] idx, input [7:0] exp);
        begin
            if (u_top.u_cpu.u_reg_f.regs[idx] !== exp) begin
                $display("FAIL r%0d = 0x%02x (期望 0x%02x)", idx, u_top.u_cpu.u_reg_f.regs[idx], exp);
                errors = errors + 1;
            end
            else $display("OK   r%0d = 0x%02x", idx, u_top.u_cpu.u_reg_f.regs[idx]);
        end
    endtask

    initial begin
        #800;
        $display("---- HALT 后寄存器 ----");
        checkr(8'd1, 8'h5A);
        checkr(8'd2, 8'h5A);
        checkr(8'd3, 8'h00);   // HALT 后第一条：停机则永不执行，跳过则也被跳过 → 都该是 0
        $display("INFO r4 = 0x%02x (HALT 后第二条；HALT 真停机→0，只停一拍→0x24)",
            u_top.u_cpu.u_reg_f.regs[4]);
        $display("INFO stage=%b frz=%b", u_top.u_cpu.stage, u_top.u_cpu.u_decoder.frz);

        // pc 双采样：t1/t2 一样 = 已停机；不一样 = 还在跑
        #100;
        $display("INFO pc@t1 = %0h", u_top.u_cpu.u_pc.pc_addr);
        #400;
        $display("INFO pc@t2 = %0h (t1/t2 不同=CPU 仍在跑)", u_top.u_cpu.u_pc.pc_addr);

        if (errors == 0) $display("===== HALT TEST RUN COMPLETED (regs checked) =====");
        else $display("===== HALT TEST FAIL: %0d error(s) =====", errors);
        $finish;
    end

    initial begin
        #30000;
        $display("===== TIMEOUT =====");
        $finish;
    end
endmodule
