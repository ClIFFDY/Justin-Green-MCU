`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/14 04:17:27
// Design Name:
// Module Name: mcu_full_tb
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// MCU 整机测试（mcu_full_tb）：针对重构后的总线化架构
//   single_mcu_top = single_cpu_top + uart_top + data_ram（外设经总线挂载）
// 载入 cpu_full_test.hex（综合大程序），一次检查：
//   段1 算术/逻辑自检（r1..r11）→ 段2 调用返回（r12..r14）
//   段3 UART 回环（发字节 → 翻转 → 回发）
// 地址映射：data_ram=0x2000 段、uart=0x4000 段（hex 已对齐）。
// 运行：cd project_self-try.srcs && /d/iverilog/bin/iverilog -g2012 -o mcu_sim \
//          sources_1/new/*.v sim_1/new/mcu_full_tb.v && /d/iverilog/bin/vvp mcu_sim
//////////////////////////////////////////////////////////////////////////////////

module mcu_full_tb;

    reg clk = 0, rst_n = 1, rx = 1;
    wire tx;

    single_mcu_top u_top(
        .clk(clk),
        .rst_n(rst_n),
        .rx(rx),
        .tx(tx)
    );

    always #10 clk = ~clk;   // 50MHz

    localparam MCNT = 434;   // 115200 @ 50MHz 每 bit 拍数

    integer errors = 0;

    // ===== CPU tx 接收模型 =====
    reg tx_d = 1;
    reg rxing = 0;
    reg [15:0] s_cnt = 0;
    reg [3:0]  nbit = 0;
    reg [7:0]  rbyte = 0;
    reg [7:0]  got [0:15];
    reg [3:0]  got_cnt = 0;

    always @(posedge clk) begin
        tx_d <= tx;
        if (rxing) begin
            s_cnt <= s_cnt + 1;
            if (s_cnt == MCNT/2 - 1 + nbit * MCNT) begin
                if (nbit == 0) begin
                    if (tx !== 1'b0) $display("FAIL: tx 起始位非 0");
                    nbit <= nbit + 1;
                end
                else if (nbit <= 8) begin
                    rbyte[nbit - 1] <= tx;
                    nbit <= nbit + 1;
                end
                else begin
                    if (tx !== 1'b1) $display("FAIL: tx 停止位非 1");
                    got[got_cnt] <= rbyte;
                    got_cnt <= got_cnt + 1;
                    rxing <= 0;
                    $display("CPU TX @%0t  0x%02x  (%c)", $time, rbyte, rbyte);
                end
            end
        end
        else if (tx_d && !tx) begin
            rxing <= 1; s_cnt <= 0; nbit <= 0; rbyte <= 0;
        end
    end

    // ===== tb 往 rx 发帧 =====
    task sbit(input v);
        begin rx = v; #(MCNT * 20); end
    endtask
    task sbyte(input [7:0] v);
        integer i;
        begin
            sbit(1'b0);
            for (i = 0; i < 8; i = i + 1) sbit(v[i]);
            sbit(1'b1);
        end
    endtask

    // ===== 载入指令（MCU 顶层下 u_cpu 内 ins_rom）=====
    initial begin
        $readmemh("E:/Vivado_Projects/project_self-try/project_self-try.srcs/cpu_full_test.hex", u_top.u_cpu.u_ins_rom.mem);
    end

    // ===== 复位 =====
    initial begin
        rst_n = 0;
        #20
        rst_n = 1;
    end

    // ===== 寄存器检查（层次引用 u_cpu.u_reg_f.regs）=====
    task checkr(input [7:0] idx, input [7:0] exp);
        begin
            if (u_top.u_cpu.u_reg_f.regs[idx] !== exp) begin
                $display("FAIL r%0d = 0x%02x (期望 0x%02x)", idx, u_top.u_cpu.u_reg_f.regs[idx], exp);
                errors = errors + 1;
            end
            else
                $display("OK   r%0d = 0x%02x", idx, u_top.u_cpu.u_reg_f.regs[idx]);
            end
    endtask

    // ===== 主流程 =====
    initial begin
        #8000;
        $display("---- 段1 算术/逻辑自检 ----");
        checkr(8'd1,  8'h41);
        checkr(8'd2,  8'h42);
        checkr(8'd3,  8'h3A);
        checkr(8'd4,  8'h0F);
        checkr(8'd5,  8'h0A);
        checkr(8'd6,  8'h3A);
        checkr(8'd7,  8'h22);
        checkr(8'd8,  8'h78);
        checkr(8'd9,  8'h1E);
        checkr(8'd10, 8'h01);
        checkr(8'd11, 8'h00);
        $display("---- 段2 调用返回 ----");
        checkr(8'd12, 8'h24);
        checkr(8'd13, 8'h27);
        checkr(8'd14, 8'hAA);

        // ---- 段3 UART 回环 ----
        $display("---- 段3 UART 回环 ----");
        $display("TB: 发送 'a' (0x61)，期望回 'A' (0x41)");
        sbyte(8'h61);
        while (got_cnt < 1) #1000;
        if (got[0] !== 8'h41) begin
            $display("FAIL 回发[0] = 0x%02x (期望 0x41)", got[0]);
            errors = errors + 1;
        end

        if (errors == 0)
            $display("===== ALL TESTS PASSED (%0d bytes) =====", got_cnt);
        else
            $display("===== FAIL: %0d error(s) =====", errors);
        $finish;
    end

    // 兜底
    initial begin
        #600000;
        $display("===== TIMEOUT =====");
        $finish;
    end

endmodule
