`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: reg_f
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module reg_f(
    input wire clk,
    input wire we, 
    input wire [1:0] jmpflg,
    input wire [15:0] addr_12, addr_12_imm,
    input wire [7:0] rd,
    input wire [7:0] ra_in,
    input wire [7:0] rd_data,
    output wire [7:0] ra,
    output wire [15:0] r12_data, r12_data_imm
    );

    reg [7:0] regs [0:255];
    reg [7:0] rad [0:63];

    integer i;
    reg [5:0] j;

    initial begin
        for (i = 0; i < 64; i = i + 1) regs[i] = 8'd0;
        for (i = 0; i < 16; i = i + 1) rad[i] = 8'd0;
        j = 6'b0;
    end

    wire [7:0] r1 = addr_12[15:8];
    wire [7:0] r2 = addr_12[7:0];
    wire [7:0] r1_imm = addr_12_imm[15:8];
    wire [7:0] r2_imm = addr_12_imm[7:0];

    assign r12_data[15:8] = (r1 == 8'b0) ? 0 : regs[r1];
    assign r12_data[7:0] = (r2 == 8'b0) ? 0 : regs[r2];
    assign r12_data_imm[15:8] = (r1_imm == 8'b0) ? 0 : regs[r1_imm];
    assign r12_data_imm[7:0] = (r2_imm == 8'b0) ? 0 : regs[r2_imm];

    assign ra = rad[j - 1];

    always @(posedge clk) begin
        if (we && rd != 0) regs[rd] <= rd_data;
        if (jmpflg[1] && ra_in != 0) begin
            rad[j] <= ra_in;
            j <= j + 1;
        end
        else if (jmpflg[0] && j != 6'b0) begin
            rad[j - 1] <= 8'b0;
            j <= j - 1;
        end
    end
endmodule
