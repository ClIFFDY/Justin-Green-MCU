`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: pc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pc(
    input wire clk, rst, 
    input wire [1:0] jmpret,
    input wire [2:0] stage,
    input wire [5:0] opcode,
    input wire [7:0] bytins, bytmov,
    output reg [7:0] addr
    );

    reg [7:0] nextadd;
    reg [7:0] bytnum;
    reg jmped;

    localparam [2:0] 
    IDLE = 3'b000, 
    FET = 3'b001, 
    OPR  = 3'b010, 
    WRT  = 3'b011;

    localparam [5:0] 
    LJMP = 6'b00_1000,
    RJMP = 6'b00_1001;
    
    always@(posedge clk or posedge rst) begin
        if (rst) begin 
            addr <= 8'd0;
            bytnum <= 8'b0;
            jmped <= 1'b0;
        end
        else if (stage == FET) begin
            addr <= addr + 1;
            if (bytnum != 8'b0) bytnum <= bytnum - 1;
        end
        else if (stage == OPR) begin
            if (opcode == LJMP || opcode == RJMP) begin
                bytnum <= bytins + 1;
                nextadd <= addr;
                jmped <= 1'b1;
                case (opcode[0])
                1'b0: addr <= addr - bytmov;
                1'b1: addr <= addr + bytmov;
                default: addr <= addr + 1;
                endcase
            end
        end
        else if (stage == WRT) begin
            if (bytnum == 8'b0) begin 
                if(jmpret == 2'b01 && jmped == 1'b1) begin
                   addr <= nextadd;
                   jmped <= 1'b0; 
                end 
            end
        end
    end
endmodule
