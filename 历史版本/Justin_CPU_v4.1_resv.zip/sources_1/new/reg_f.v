`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: reg_f
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module reg_f(
    input wire clk,
    input wire [2:0] stage,
    input wire we,
    input wire [5:0] addr1, addr2, waddr,
    input wire [7:0] wdata,
    output wire [7:0] rs1_data, rs2_data
    );

    wire [5:0] rs1, rs2;
    reg [7:0] regs [0:63];
    integer i;

    assign rs1 = addr1;
    assign rs2 = addr2;
    assign rs1_data = (rs1 == 4'b0) ? 0 : regs[rs1];
    assign rs2_data = (rs2 == 4'b0) ? 0 : regs[rs2];

    initial begin
        for (i = 0; i < 64; i = i + 1) regs[i] = 8'd0;
    end

    always @(posedge clk) begin
        if (stage == 3'b011 && we && waddr != 0) regs[waddr] <= wdata;
    end

endmodule
