`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 02:43:51
// Design Name: 
// Module Name: ir
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ir(
    input wire clk,
    input wire [2:0] stage,
    input wire [5:0] op_in, addr1_in, addr2_in, rd_in,
    input wire [7:0] imm_in,
    output reg [5:0] opcode, addr1, addr2, waddr,
    output reg [7:0] imm8
    );

    localparam [5:0] 
    LJMP = 6'b00_1000,
    RJMP = 6'b00_1001;

    always@(posedge clk) begin
        if (stage == 3'b010) begin
            opcode <= op_in;
            addr1 <= addr1_in;
            addr2 <= addr2_in;
            imm8 <= imm_in;
            if (op_in==LJMP || op_in==RJMP) waddr <= 0;
            else waddr <= rd_in;
        end
    end
endmodule
