`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/09 22:05:38
// Design Name:
// Module Name: ins_rom
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module ins_rom(
    input wire [7:0] addr,
    output wire [7:0] inst
    );

    reg[7:0] mem [0:255];

    initial begin

        // 准备操作数：r1 = 10（0b1010），r2 = 3（0b0011）
        // mem[0] ADDI r1 = r1 + 10
        mem[0] = 8'b000001_00;  // opcode = ADDI
        mem[1] = 8'b000001_01;  // rd  = r1
        mem[2] = 8'b000001_10;  // addr1 = r1
        mem[3] = 8'b001010_11;  // imm8 = 10

        // mem[4] ADDI r2 = r2 + 3
        mem[4] = 8'b000001_00;  // opcode = ADDI
        mem[5] = 8'b000010_01;  // rd  = r2
        mem[6] = 8'b000010_10;  // addr1 = r2
        mem[7] = 8'b000011_11;  // imm8 = 3

        // mem[8]  AND  r3 = r1 & r2   → 10 & 3 = 2
        mem[8]  = 8'b000101_00; // opcode = AND
        mem[9]  = 8'b000011_01; // rd  = r3
        mem[10] = 8'b000001_10; // addr1 = r1
        mem[11] = 8'b000010_11; // addr2 = r2

        // mem[12] OR   r4 = r1 | r2   → 10 | 3 = 11
        mem[12] = 8'b000110_00; // opcode = OR
        mem[13] = 8'b000100_01; // rd  = r4
        mem[14] = 8'b000001_10; // addr1 = r1
        mem[15] = 8'b000010_11; // addr2 = r2

        // mem[16] XOR  r5 = r1 ^ r2   → 10 ^ 3 = 9
        mem[16] = 8'b000111_00; // opcode = XOR
        mem[17] = 8'b000101_01; // rd  = r5
        mem[18] = 8'b000001_10; // addr1 = r1
        mem[19] = 8'b000010_11; // addr2 = r2

        // mem[20] ANDI r6 = r1 & 6    → 10 & 6 = 2
        mem[20] = 8'b001010_00; // opcode = ANDI
        mem[21] = 8'b000110_01; // rd  = r6
        mem[22] = 8'b000001_10; // addr1 = r1
        mem[23] = 8'b000110_11; // imm8 = 6

        // mem[24] ORI  r7 = r1 | 6    → 10 | 6 = 14
        mem[24] = 8'b001011_00; // opcode = ORI
        mem[25] = 8'b000111_01; // rd  = r7
        mem[26] = 8'b000001_10; // addr1 = r1
        mem[27] = 8'b000110_11; // imm8 = 6

        // mem[28] XORI r8 = r1 ^ 6    → 10 ^ 6 = 12
        mem[28] = 8'b001100_00; // opcode = XORI
        mem[29] = 8'b001000_01; // rd  = r8
        mem[30] = 8'b000001_10; // addr1 = r1
        mem[31] = 8'b000110_11; // imm8 = 6

        // mem[32] SLL  r9 = r1 << r2  → 10 << 3 = 80
        mem[32] = 8'b001101_00; // opcode = SLL
        mem[33] = 8'b001001_01; // rd  = r9
        mem[34] = 8'b000001_10; // addr1 = r1
        mem[35] = 8'b000010_11; // addr2 = r2（移位量）

        // mem[36] SRL  r10 = r1 >> r2 → 10 >> 3 = 1
        mem[36] = 8'b001110_00; // opcode = SRL
        mem[37] = 8'b001010_01; // rd  = r10
        mem[38] = 8'b000001_10; // addr1 = r1
        mem[39] = 8'b000010_11; // addr2 = r2（移位量）

        // mem[40] SLLI r12 = r1 << 3  → 10 << 3 = 80
        mem[40] = 8'b001111_00; // opcode = SLLI
        mem[41] = 8'b001100_01; // rd  = r12
        mem[42] = 8'b000001_10; // addr1 = r1
        mem[43] = 8'b000011_11; // imm8 = 3

        // mem[44] SRLI r13 = r1 >> 2  → 10 >> 2 = 2
        mem[44] = 8'b010000_00; // opcode = SRLI
        mem[45] = 8'b001101_01; // rd  = r13
        mem[46] = 8'b000001_10; // addr1 = r1
        mem[47] = 8'b000010_11; // imm8 = 2

        // mem[48] SLTU r15 = (r1 < r2)  → (10 < 3) = 0
        mem[48] = 8'b010001_00; // opcode = SLTU
        mem[49] = 8'b001111_01; // rd  = r15
        mem[50] = 8'b000001_10; // addr1 = r1
        mem[51] = 8'b000010_11; // addr2 = r2

        // mem[52] SLTIU r16 = (r1 < 12) → (10 < 12) = 1
        mem[52] = 8'b010010_00; // opcode = SLTIU
        mem[53] = 8'b010000_01; // rd  = r16
        mem[54] = 8'b000001_10; // addr1 = r1
        mem[55] = 8'b001100_11; // imm8 = 12

        // mem[56] HALT 停机
        mem[56] = 8'b000000_00; // opcode = HALT
        mem[57] = 8'b000000_01;
        mem[58] = 8'b000000_10;
        mem[59] = 8'b000000_11;

    end

    assign inst = mem[addr];
endmodule

    // localparam [5:0]
    // HALT  = 6'b00_0000,
    // ADDI  = 6'b00_0001,
    // ADD   = 6'b00_0010,
    // SUBI  = 6'b00_0011,
    // SUB   = 6'b00_0100,
    // AND   = 6'b00_0101,
    // OR    = 6'b00_0110,
    // XOR   = 6'b00_0111,
    // LJMP  = 6'b00_1000,
    // RJMP  = 6'b00_1001,
    // ANDI  = 6'b00_1010,
    // ORI   = 6'b00_1011,
    // XORI  = 6'b00_1100,
    // SLL   = 6'b00_1101,
    // SRL   = 6'b00_1110,
    // SLLI  = 6'b00_1111,
    // SRLI  = 6'b01_0000,
    // SLTU  = 6'b01_0001,
    // SLTIU = 6'b01_0010;
