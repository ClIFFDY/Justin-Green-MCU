`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:49:40
// Design Name: 
// Module Name: fsm
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsm(
    input wire clk, rst, frz,
    input wire [7:0] inst_raw,
    output reg [2:0] stage,
    output reg we
    );
    
    localparam [2:0] 
    IDLE = 3'b000, 
    FET = 3'b001, 
    OPR  = 3'b010, 
    WRT  = 3'b011;

    always @(posedge clk or posedge rst) begin
        if (rst) begin 
            stage <= FET;
            we <= 1'b1;
        end
        else begin
            case (stage)
            IDLE: begin
                if (!frz) begin
                    we <= 1'b1;
                    stage <= FET;   
                end 
            end
            FET: begin 
                if (inst_raw[1:0] != 2'b11) stage <= FET;
                else stage <= OPR;
            end
            OPR: begin 
                if (frz) begin 
                    stage <= IDLE;
                    we <= 1'b0;
                end
                else stage <= WRT;
            end
            WRT: stage <= FET;
            default: stage <= IDLE;
            endcase
        end
    end
endmodule
