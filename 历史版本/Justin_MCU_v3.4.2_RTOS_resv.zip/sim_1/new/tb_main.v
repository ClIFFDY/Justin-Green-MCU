`timescale 1ns / 1ps
// tb_main — 跑主固件, 抓 UART TX 字节 (0x2000 写), 看 boot/菜单打印
module tb_main;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus));
    always #10 clk = ~clk;
    integer cyc = 0;
    always @(posedge clk) begin
        cyc = cyc + 1;
        // UART 数据寄存器写 (0x2000): 打印 TX 字节
        if (u_top.u_uart.bus_sig_in[0] && u_top.u_uart.bus_addr_in == 16'h2000)
            $write("%c", u_top.u_uart.bus_data_in);
        // 每 50K 周期报 pc (看卡哪)
        if (cyc % 500000 == 0)
            $display("T%0d pc=%03X", cyc, u_top.u_cpu.u_pc.pc_addr);
        // timer cnt[2] 读取探针
        if (u_top.u_cpu.u_decoder.bus_addr_out == 16'h3002 &&
            u_top.u_cpu.u_decoder.bus_sig_out[0] == 1'b0)
            $display("READ cnt2=%02X @pc=%03X T=%0d", u_top.u_timer.cnt[2], u_top.u_cpu.u_pc.pc_addr, cyc);
    end
    initial begin
        repeat(4000000) @(posedge clk);
        $display("=== END pc=%03X ===", u_top.u_cpu.u_pc.pc_addr);
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
        // 仿真 UART tx_busy 卡住, 强制 0 让 fast_putc/putc 不等待 (字节仍被 tb 捕获)
        force u_top.u_uart.tx_busy = 1'b0;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
