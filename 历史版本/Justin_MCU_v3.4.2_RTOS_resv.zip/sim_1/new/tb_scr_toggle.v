`timescale 1ns / 1ps
// tb_scr_toggle — 关屏/开屏门控验证（v2: 流 dump + SCREEN_OFF 变迁监控）
//   boot→主菜单 → '0'关屏(0xAE) → '2'忽略 → '0'开屏(0xAF+重画)
module tb_scr_toggle;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    pullup (gpio_pin_bus[4]); pullup (gpio_pin_bus[5]);
    wire err_led;
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus),
        .err_led(err_led));
    always #10 clk = ~clk;
    wire scl = gpio_pin_bus[4];
    wire sda = gpio_pin_bus[5];

    reg prev_scl = 1, prev_sda = 1;
    integer ack_cnt = 0;
    always @(posedge clk) begin
        if (scl && !prev_scl) begin
            ack_cnt = ack_cnt + 1;
            if ((ack_cnt % 9) == 0) force gpio_pin_bus[5] = 1'b0;
        end
        if (!scl && prev_scl) begin
            if ((ack_cnt % 9) == 0) release gpio_pin_bus[5];
        end
        prev_scl = scl;
        prev_sda = sda;
    end

    integer nw = 0;
    reg [7:0] stream [0:32767];
    reg [15:0] stream_addr [0:32767];
    always @(posedge clk) begin
        if (u_top.u_i2c_out.bus_addr_final[15:12] == 4'h1 && u_top.u_i2c_out.bus_sig_final[0] && nw < 32768) begin
            stream[nw] = u_top.u_i2c_out.bus_data_final;
            stream_addr[nw] = u_top.u_i2c_out.bus_addr_final;
            nw = nw + 1;
        end
    end

    reg [7:0] gddram [0:1023];
    integer idx, p, c, s, q, cc;
    integer mode = 0, expect_mode = 0, expect_param = 0, last_range = 0;
    integer cyc = 0;
    integer last_nw = 0, stable = 0;
    integer wait_cnt = 0;
    integer phase = 0;
    integer freeze = 0, last_pc = 0;

    always @(posedge clk) begin
        if (u_top.u_cpu.u_pc.pc_addr != last_pc) freeze = 0;
        else freeze = freeze + 1;
        last_pc = u_top.u_cpu.u_pc.pc_addr;
    end

    // ---- SCREEN_OFF 变迁监控 ----
    reg scr_prev = 0;
    always @(posedge clk) begin
        if (u_top.u_ram_top.ram_sec_1.mem[16'h436] !== scr_prev) begin
            $display("  [SCROFF %0d→%0d @%0d pc=%04X]", scr_prev,
                u_top.u_ram_top.ram_sec_1.mem[16'h436], cyc, last_pc);
            scr_prev = u_top.u_ram_top.ram_sec_1.mem[16'h436];
        end
    end

    // ---- 流 dump：nw 区间 [a,b] 显示带地址的原始字节 ----
    task dump_stream; input integer a; input integer b; begin
        for (idx = a; idx < b; idx = idx + 1)
            $display("    s[%0d]=%02X @%04X", idx, stream[idx], stream_addr[idx]);
    end endtask

    integer has_ae, has_af;
    task scan_range; input integer a; input integer b; begin
        has_ae = 0; has_af = 0;
        for (idx = a; idx < b; idx = idx + 1)
            if (stream_addr[idx] == 16'h1000) begin
                if (stream[idx] == 8'hAE) has_ae = 1;
                if (stream[idx] == 8'hAF) has_af = 1;
            end
    end endtask

    task inject_key; input [7:0] k; begin
        u_top.u_ram_top.ram_sec_2.mem[16'h100] = k;
        u_top.u_ram_top.ram_sec_2.mem[16'h108] = 1;
        u_top.u_ram_top.ram_sec_2.mem[16'h109] = 0;
        $display("== 注入 '%c' @%0d ==", k, cyc);
    end endtask

    always @(posedge clk) begin
        cyc = cyc + 1;
        case (phase)
            0: begin  // 等主菜单画完稳定
                if (nw > 1380) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 400000) begin
                        $display("== 主菜单稳定 @%0d nw=%0d ==", cyc, nw);
                        last_nw = nw; stable = 0;
                        wait_cnt = 0; phase = 1;
                    end
                end
            end
            1: begin  // 注入 '0' → 关屏
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("0");
                    wait_cnt = 0; phase = 2;
                end
            end
            2: begin  // 等 SCREEN_OFF=1 且流里出现 0xAE（命令发完）
                if (u_top.u_ram_top.ram_sec_1.mem[16'h436] == 1) begin
                    scan_range(last_nw, nw);
                    if (has_ae) begin
                        $display("== 关屏完成 @%0d (0xAE 已发) nw=%0d ==", cyc, nw);
                        last_nw = nw; stable = 0;
                        wait_cnt = 0; phase = 3;
                    end
                    else if (cyc % 100000 == 0 && wait_cnt < 2) begin
                        wait_cnt = wait_cnt + 1;
                        if (wait_cnt == 1) begin
                            $display("  [WARN] SCREEN_OFF=1 但 0xAE 未出现, dump 区间 [%0d,%0d):", last_nw, nw);
                            dump_stream(last_nw, nw);
                        end
                    end
                end
                if (cyc > 13000000) begin
                    $display("!! 关屏超时 SCROFF=%0d nw=%0d", u_top.u_ram_top.ram_sec_1.mem[16'h436], nw);
                    scan_range(last_nw, nw);
                    $display("  0xAE=%0d 0xAF=%0d", has_ae, has_af);
                    dump_stream(last_nw, nw);
                    $finish;
                end
            end
            3: begin  // 注入 '2' → 应被忽略
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("2");
                    wait_cnt = 0; phase = 4;
                end
            end
            4: begin  // 等流稳定，验证 SEL 未变 + SCREEN_OFF 仍 1 + 无新 I2C
                if (nw != last_nw) stable = 0;
                else stable = stable + 1;
                last_nw = nw;
                if (stable > 300000) begin
                    $display("== 忽略检查 @%0d SEL=%0d SCREEN_OFF=%0d MENU=%0d ==", cyc,
                        u_top.u_ram_top.ram_sec_1.mem[16'h433],
                        u_top.u_ram_top.ram_sec_1.mem[16'h436],
                        u_top.u_ram_top.ram_sec_2.mem[16'h11C]);
                    if (u_top.u_ram_top.ram_sec_1.mem[16'h433] != 0) $display("  [FAIL] '2' 未被忽略! SEL 变了");
                    else $display("  [PASS] '2' 被忽略, SEL 保持 0");
                    wait_cnt = 0; phase = 5;
                end
            end
            5: begin  // 注入 '0' → 开屏
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("0");
                    wait_cnt = 0; phase = 6;
                end
            end
            6: begin  // 等 SCREEN_OFF=0 + 流里出现 0xAF + 重画完
                if (u_top.u_ram_top.ram_sec_1.mem[16'h436] == 0) begin
                    scan_range(last_nw, nw);
                    if (has_af) begin
                        if (nw != last_nw) stable = 0;
                        else stable = stable + 1;
                        last_nw = nw;
                        if (stable > 400000) begin
                            $display("== 开屏完成 @%0d (0xAF 已发) nw=%0d ==", cyc, nw);
                            scan_range(last_nw, nw);
                            $display("  开屏后流 0xAF=%0d", has_af);
                            $finish;
                        end
                    end
                end
                if (cyc > 18000000) begin
                    $display("!! 开屏超时 SCROFF=%0d nw=%0d", u_top.u_ram_top.ram_sec_1.mem[16'h436], nw);
                    scan_range(last_nw, nw);
                    dump_stream(last_nw, nw);
                    $finish;
                end
            end
        endcase
        if (freeze > 3000000) begin
            $display("!! PC 冻结 %0d 拍 @cyc=%0d pc=%04X —— 疑似挂死", freeze, cyc, last_pc);
            $finish;
        end
        if (cyc % 1000000 == 0) $display("T%0d cyc=%0d nw=%0d MENU=%0d SEL=%0d SCROFF=%0d pc=%04X",
            cyc, cyc, nw,
            u_top.u_ram_top.ram_sec_2.mem[16'h11C], u_top.u_ram_top.ram_sec_1.mem[16'h433],
            u_top.u_ram_top.ram_sec_1.mem[16'h436], last_pc);
    end

    initial begin
        repeat(18500000) @(posedge clk);
        $display("=== END @%0d ===", cyc);
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
        force u_top.u_uart.tx_busy = 1'b0;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
