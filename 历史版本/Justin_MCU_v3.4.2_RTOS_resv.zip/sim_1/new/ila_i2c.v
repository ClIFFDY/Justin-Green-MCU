// ila_i2c 仿真 stub (64 位单探针; 仿真时忽略 ILA)
module ila_i2c(
    input wire clk,
    input wire [63:0] probe0
);
endmodule
