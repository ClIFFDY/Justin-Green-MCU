`timescale 1ns / 1ps
// tb_irq_stress — IRQ resume 边界压力测试仿真
// 跑 irq_stress_test.asm, 抓 UART 输出; 输出停在哪 = 该模式 resume 崩
module tb_irq_stress;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus));
    always #10 clk = ~clk;

    integer cyc = 0;
    integer last_uart = 0;
    integer hang_cnt = 0;
    always @(posedge clk) begin
        cyc = cyc + 1;
        if (u_top.u_uart.bus_sig_in[0] && u_top.u_uart.bus_addr_in == 16'h2000) begin
            $write("%c", u_top.u_uart.bus_data_in);
            last_uart = cyc;
        end
        // 挂起检测: 250K 周期无 UART 输出 → 报停在哪
        if (cyc - last_uart > 250000 && last_uart > 0 && cyc > 400000) begin
            $display("\n== 疑似挂起 @T%0d (无 UART 输出 250K 周期), pc=%03X ==", cyc,
                u_top.u_cpu.u_pc.pc_addr);
            $finish;
        end
        if (cyc % 1000000 == 0)
            $display("\n@T%0d pc=%03X irq_cnt=%0d prog=%02X", cyc,
                u_top.u_cpu.u_pc.pc_addr,
                u_top.u_ram_top.ram_sec_1.mem[16'h504],
                u_top.u_ram_top.ram_sec_1.mem[16'h500]);
    end

    initial begin
        repeat(1300000) @(posedge clk);
        $display("\n=== END ===");
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
        force u_top.u_uart.tx_busy = 1'b0;
        // 注入 UART RX '0' → 跑全部模式
        repeat(25000) @(posedge clk);
        force u_top.u_uart.rx_data = 8'h30;   // '0'
        force u_top.u_uart.rx_done = 1;
        repeat(1) @(posedge clk);
        release u_top.u_uart.rx_done;
        release u_top.u_uart.rx_data;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
