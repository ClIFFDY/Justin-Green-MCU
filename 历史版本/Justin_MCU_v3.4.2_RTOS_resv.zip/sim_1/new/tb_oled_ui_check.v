`timescale 1ns / 1ps
// tb_oled_ui_check — 交互回归: boot→主菜单(横向全刷)→'2'光标下移(页模式局部)→'5'选CREDITS(横向全刷)
// 每步 dump 显示模型 vs FB + PC 冻结看门狗（挂死检测）
module tb_oled_ui_check;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    pullup (gpio_pin_bus[4]);   // SCL
    pullup (gpio_pin_bus[5]);   // SDA
    wire err_led;
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus),
        .err_led(err_led));
    always #10 clk = ~clk;
    wire scl = gpio_pin_bus[4];
    wire sda = gpio_pin_bus[5];

    reg prev_scl = 1, prev_sda = 1;
    integer ack_cnt = 0;
    always @(posedge clk) begin
        if (scl && !prev_scl) begin
            ack_cnt = ack_cnt + 1;
            if ((ack_cnt % 9) == 0) force gpio_pin_bus[5] = 1'b0;
        end
        if (!scl && prev_scl) begin
            if ((ack_cnt % 9) == 0) release gpio_pin_bus[5];
        end
        prev_scl = scl;
        prev_sda = sda;
    end

    integer nw = 0;
    reg [7:0] stream [0:32767];
    reg [15:0] stream_addr [0:32767];
    always @(posedge clk) begin
        if (u_top.u_i2c_out.bus_addr_final[15:12] == 4'h1 && u_top.u_i2c_out.bus_sig_final[0] && nw < 32768) begin
            stream[nw] = u_top.u_i2c_out.bus_data_final;
            stream_addr[nw] = u_top.u_i2c_out.bus_addr_final;
            nw = nw + 1;
        end
    end

    reg [7:0] gddram [0:1023];
    integer idx, p, c, s, q, cc;
    integer mode = 0, expect_mode = 0, expect_param = 0, last_range = 0;
    integer cyc = 0;
    always @(posedge clk) cyc = cyc + 1;

    integer last_nw = 0, stable = 0;
    integer wait_cnt = 0;
    integer phase = 0;
    integer freeze = 0, last_pc = 0;

    always @(posedge clk) begin
        if (u_top.u_cpu.u_pc.pc_addr != last_pc) freeze = 0;
        else freeze = freeze + 1;
        last_pc = u_top.u_cpu.u_pc.pc_addr;
    end

    // ---- 抓每个 IRQ 的 pcIn 和 resume（找恢复错乱点）----
    reg [3:0] st_d1 = 0;
    reg [12:0] pc_d1 = 0;
    reg [12:0] irq_pc [0:49];
    reg [12:0] irq_rs [0:49];
    reg [1:0] irq_bub [0:49];
    reg [8:0] irq_src [0:49];
    reg [2:0] irq_tprio [0:49];
    integer irq_t [0:49];
    reg [12:0] irq_tcb0 [0:49];
    integer irq_h = 0;
    integer qi;
    always @(posedge clk) begin
        pc_d1 <= u_top.u_cpu.u_pc.pc_addr;
        st_d1 <= u_top.u_cpu.u_irq_con.stage;
        if (u_top.u_cpu.u_irq_con.stage == 1 && st_d1 == 0 && irq_h < 50) begin
            irq_pc[irq_h] = pc_d1;
            irq_rs[irq_h] = u_top.u_cpu.u_irq_con.pc_addr[0];
            irq_bub[irq_h] = u_top.u_cpu.u_pc.bubble;
            irq_src[irq_h] = u_top.u_bus_controller.irq_bus;
            irq_tprio[irq_h] = u_top.u_bus_controller.irq_prio[0];
            irq_t[irq_h] = cyc;
            irq_tcb0[irq_h] = {u_top.u_ram_top.ram_sec_2.mem[16'h009], u_top.u_ram_top.ram_sec_2.mem[16'h008]};
            irq_h = irq_h + 1;
        end
    end

    task replay; begin
        idx = 0; p = 0; c = 0; s = 0; mode = 0; expect_mode = 0; expect_param = 0; last_range = 0;
        while (idx < nw) begin
            if (stream_addr[idx] == 16'h1000) begin
                if (stream[idx] == 8'h78) s = 1;
                else if (s == 1 && stream[idx] == 8'h00) s = 2;
                else if (s == 1 && stream[idx] == 8'h40) s = 3;
                else if (s == 2) begin
                    if (expect_mode) begin
                        if (stream[idx] == 8'h00) mode = 1;
                        else if (stream[idx] == 8'h02) mode = 0;
                        expect_mode = 0;
                        if (mode == 1) begin p = 0; c = 0; end
                    end
                    else if (expect_param > 0) begin
                        if (expect_param == 2) begin
                            if (last_range == 8'h21) c = stream[idx];
                            else if (last_range == 8'h22) p = stream[idx];
                        end
                        expect_param = expect_param - 1;
                    end
                    else if (stream[idx] == 8'h20) expect_mode = 1;
                    else if (stream[idx] == 8'h21 || stream[idx] == 8'h22) begin last_range = stream[idx]; expect_param = 2; end
                    else if (stream[idx] >= 8'hB0 && stream[idx] <= 8'hB7) p = stream[idx] & 8'h07;
                    else if (stream[idx] >= 8'h10 && stream[idx] <= 8'h1F) c = (stream[idx] & 8'h0F) << 4;
                    else if (stream[idx] <= 8'h0F) c = c | (stream[idx] & 8'h0F);
                end
                else if (s == 3) begin
                    gddram[p*128 + c] = stream[idx];
                    if (mode == 1) begin
                        c = c + 1;
                        if (c > 127) begin c = 0; p = p + 1; if (p > 7) p = 0; end
                    end
                    else c = (c + 1) & 8'h7F;
                end
            end
            else if (stream_addr[idx] == 16'h1600) s = 0;
            idx = idx + 1;
        end
    end endtask

    integer mism, addrsum;
    task chk; input integer pg; begin
        mism = 0; addrsum = 0;
        for (cc = 0; cc < 128; cc = cc + 1) begin
            if (gddram[pg*128+cc] !== 8'hx && gddram[pg*128+cc] !== u_top.u_ram_top.ram_sec_1.mem[pg*128+cc]) begin
                mism = mism + 1; addrsum = addrsum + cc;
            end
        end
        $display("  [@%0d] 页%0d 显示vsFB 不匹配=%0d (前3列: DISP=%02X%02X%02X FB=%02X%02X%02X)",
            cyc, pg, mism, gddram[pg*128], gddram[pg*128+1], gddram[pg*128+2],
            u_top.u_ram_top.ram_sec_1.mem[pg*128], u_top.u_ram_top.ram_sec_1.mem[pg*128+1], u_top.u_ram_top.ram_sec_1.mem[pg*128+2]);
    end endtask

    task st; begin
        $display("  [@%0d] SEL=%0d MENU=%0d nw=%0d pc=%04X freeze=%0d", cyc,
            u_top.u_ram_top.ram_sec_1.mem[16'h433],
            u_top.u_ram_top.ram_sec_2.mem[16'h11C], nw, last_pc, freeze);
    end endtask

    task inject_key; input [7:0] k; begin
        u_top.u_ram_top.ram_sec_2.mem[16'h100] = k;
        u_top.u_ram_top.ram_sec_2.mem[16'h108] = 1;
        u_top.u_ram_top.ram_sec_2.mem[16'h109] = 0;
        $display("== 注入 '%c' @%0d ==", k, cyc);
    end endtask

    always @(posedge clk) begin
        cyc = cyc + 1;
        if (cyc % 500000 == 0)
            $display("@%0d tprio=%0d j=%0d stage=%0d tcb0=%02X%02X cur=%0d pc=%04X", cyc,
                u_top.u_bus_controller.irq_prio[0],
                u_top.u_cpu.u_irq_con.j, u_top.u_cpu.u_irq_con.stage,
                u_top.u_ram_top.ram_sec_2.mem[16'h009], u_top.u_ram_top.ram_sec_2.mem[16'h008],
                u_top.u_ram_top.ram_sec_2.mem[16'h005],
                u_top.u_cpu.u_pc.pc_addr);
        case (phase)
            0: begin  // 等主菜单全流程稳定（flush+putc+flush_rx 完成，shell 回 loop）
                if (nw > 1380) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 400000) begin
                        $display("== 主菜单稳定 @%0d nw=%0d ==", cyc, nw);
                        st; replay; chk(2);
                        wait_cnt = 0; phase = 1;
                    end
                end
            end
            1: begin  // 注入 '2' 光标下移
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("2");
                    wait_cnt = 0; phase = 2;
                end
            end
            2: begin  // 等 SEL=1 + 局部刷新完成
                if (u_top.u_ram_top.ram_sec_1.mem[16'h433] == 1) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 150000) begin
                        $display("== SEL=1 光标移动完成 @%0d ==", cyc);
                        st; replay; chk(2); chk(3);
                        wait_cnt = 0; phase = 3;
                    end
                end
                else if (cyc > 12000000) begin
                    $display("!! 光标移动超时 —— IRQ 恢复抓取:");
                    for (qi = 0; qi < irq_h && qi < 50; qi = qi + 1)
                        $display("  IRQ#%0d @%0d pcIn=%04X resume=%04X tcb0=%04X bub=%0d", qi, irq_t[qi], irq_pc[qi], irq_rs[qi], irq_tcb0[qi], irq_bub[qi]);
                    $finish;
                end
            end
            3: begin  // 注入 '5' 选 CREDITS
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("5");
                    wait_cnt = 0; phase = 4;
                end
            end
            4: begin  // 等 MENU=3 (STATUS 横向全刷; SEL=1 按'5' 进 STATUS)
                if (u_top.u_ram_top.ram_sec_2.mem[16'h11C] == 3) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 100000) begin
                        $display("== STATUS 屏画完 @%0d nw=%0d ==", cyc, nw);
                        st; replay; chk(2);
                        $finish;
                    end
                end
                else if (cyc > 15000000) begin $display("!! STATUS 超时"); $finish; end
            end
        endcase
        if (freeze > 3000000) begin
            $display("!! PC 冻结 %0d 拍 @cyc=%0d pc=%04X —— 疑似挂死", freeze, cyc, last_pc);
            $finish;
        end
        if (cyc % 1000000 == 0) $display("T%0d cyc=%0d nw=%0d MENU=%0d SEL=%0d CUR_TASK=%0d RX_WR=%0d RX_RD=%0d CURSOR=%0d IDLE=%0d irq_stage=%0d pc=%04X",
            cyc, cyc, nw,
            u_top.u_ram_top.ram_sec_2.mem[16'h11C], u_top.u_ram_top.ram_sec_1.mem[16'h433],
            u_top.u_ram_top.ram_sec_2.mem[16'h005],   // CUR_TASK 0x9005
            u_top.u_ram_top.ram_sec_2.mem[16'h108],   // RX_WR
            u_top.u_ram_top.ram_sec_2.mem[16'h109],   // RX_RD
            u_top.u_ram_top.ram_sec_2.mem[16'h118],   // CURSOR
            u_top.u_ram_top.ram_sec_2.mem[16'h11A],   // IDLE_CNT
            u_top.u_cpu.u_irq_con.stage,
            last_pc);
    end

    initial begin
        repeat(15000000) @(posedge clk);
        $display("=== END @%0d ===", cyc);
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
        force u_top.u_uart.tx_busy = 1'b0;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
