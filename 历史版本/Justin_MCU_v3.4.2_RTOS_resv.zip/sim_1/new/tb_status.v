`timescale 1ns / 1ps
// tb_status — STATUS 多页验证:
//   boot→主菜单 → '2'(SEL=1) → '5'(进STATUS) → 页0(UPTIME) → 6/6/6翻页 → 4返回
//   检查 STATUS_PAGE 变迁 + 每页 nw 增长(绘制发生) + 无冻结
module tb_status;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    pullup (gpio_pin_bus[4]); pullup (gpio_pin_bus[5]);
    wire err_led;
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus),
        .err_led(err_led));
    always #10 clk = ~clk;
    wire scl = gpio_pin_bus[4];
    wire sda = gpio_pin_bus[5];

    reg prev_scl = 1, prev_sda = 1;
    integer ack_cnt = 0;
    always @(posedge clk) begin
        if (scl && !prev_scl) begin
            ack_cnt = ack_cnt + 1;
            if ((ack_cnt % 9) == 0) force gpio_pin_bus[5] = 1'b0;
        end
        if (!scl && prev_scl) begin
            if ((ack_cnt % 9) == 0) release gpio_pin_bus[5];
        end
        prev_scl = scl;
        prev_sda = sda;
    end

    integer nw = 0;
    reg [7:0] stream [0:32767];
    reg [15:0] stream_addr [0:32767];
    always @(posedge clk) begin
        if (u_top.u_i2c_out.bus_addr_final[15:12] == 4'h1 && u_top.u_i2c_out.bus_sig_final[0] && nw < 32768) begin
            stream[nw] = u_top.u_i2c_out.bus_data_final;
            stream_addr[nw] = u_top.u_i2c_out.bus_addr_final;
            nw = nw + 1;
        end
    end

    integer cyc = 0;
    integer last_nw = 0, stable = 0;
    integer wait_cnt = 0;
    integer base_nw = 0;
    integer phase = 0;
    integer freeze = 0, last_pc = 0;


    always @(posedge clk) begin
        if (u_top.u_cpu.u_pc.pc_addr != last_pc) freeze = 0;
        else freeze = freeze + 1;
        last_pc = u_top.u_cpu.u_pc.pc_addr;
    end

    // ---- 跳过 oled_init 上电延时（0x15D7-0x15DF 三层循环）加速仿真 ----
    // GPIO+I2C_CFG 配置在 0x15D4-0x15D6（保留）；仅跳过延时循环
    // pc 进入延时区 → force 到 0x15E0（延时后第一条），保持 30 拍冲刷管线后释放
    reg dly_hold = 0; reg [4:0] dly_cnt = 0;
    always @(posedge clk) begin
        if (dly_hold) begin
            if (dly_cnt == 5'd30) begin
                release u_top.u_cpu.u_pc.pc_addr;
                dly_hold = 0; dly_cnt = 0;
            end
            else dly_cnt = dly_cnt + 1;
        end
        else if (u_top.u_cpu.u_pc.pc_addr >= 16'h15CB && u_top.u_cpu.u_pc.pc_addr <= 16'h15D3) begin
            force u_top.u_cpu.u_pc.pc_addr = 13'h15D4;
            dly_hold = 1; dly_cnt = 0;
        end
    end

    task inject_key; input [7:0] k; begin
        base_nw = nw;
        u_top.u_ram_top.ram_sec_2.mem[16'h100] = k;
        u_top.u_ram_top.ram_sec_2.mem[16'h108] = 1;
        u_top.u_ram_top.ram_sec_2.mem[16'h109] = 0;
        $display("== 注入 '%c' @%0d ==", k, cyc);
    end endtask

    always @(posedge clk) begin
        cyc = cyc + 1;
        case (phase)
            0: begin  // 等主菜单稳定
                if (nw > 1380) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 300000) begin
                        $display("== 主菜单稳定 @%0d nw=%0d SEL=%0d ==", cyc, nw,
                            u_top.u_ram_top.ram_sec_1.mem[16'h433]);
                        stable = 0; wait_cnt = 0; phase = 1;
                    end
                end
            end
            1: begin  // '2' → SEL=1 (STATUS)
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("2");
                    wait_cnt = 0; phase = 2;
                end
            end
            2: begin  // 等 SEL==1 且 nw 稳定（render_main 完成后才注入下一个键）
                if (u_top.u_ram_top.ram_sec_1.mem[16'h433] == 1) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 200000) begin
                        $display("== SEL=1 绘制完成 @%0d nw=%0d ==", cyc, nw);
                        wait_cnt = 0; phase = 3;
                    end
                end
                else if (cyc > 9000000) begin $display("!! SEL=1 超时"); $finish; end
            end
            3: begin  // '5' → 进 STATUS (MENU=3)
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("5");
                    wait_cnt = 0; phase = 4;
                end
            end
            4: begin  // 等 MENU==3 + 页0画完（nw 相对注入点增长 + 持续稳定）
                if (u_top.u_ram_top.ram_sec_2.mem[16'h11C] == 3) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (nw > base_nw + 800 && stable > 300000) begin
                        $display("== STATUS 页0 画完 @%0d nw=%0d STATUS_PAGE=%0d ==", cyc, nw,
                            u_top.u_ram_top.ram_sec_1.mem[16'h437]);
                        wait_cnt = 0; phase = 5;
                    end
                end
                else if (cyc > 10000000) begin $display("!! STATUS 超时"); $finish; end
            end
            5: begin  // '6' → 页1
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("6");
                    wait_cnt = 0; phase = 6;
                end
            end
            6: begin  // 等 STATUS_PAGE==1 且画完（nw 增长 + 稳定）
                if (u_top.u_ram_top.ram_sec_1.mem[16'h437] == 1) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (nw > base_nw + 800 && stable > 300000) begin
                        $display("== STATUS 页1 画完 @%0d nw=%0d ==", cyc, nw);
                        wait_cnt = 0; phase = 7;
                    end
                end
            end
            7: begin  // '6' → 页2
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("6");
                    wait_cnt = 0; phase = 8;
                end
            end
            8: begin  // 等 STATUS_PAGE==2 且画完
                if (u_top.u_ram_top.ram_sec_1.mem[16'h437] == 2) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (nw > base_nw + 800 && stable > 300000) begin
                        $display("== STATUS 页2 画完 @%0d nw=%0d ==", cyc, nw);
                        wait_cnt = 0; phase = 9;
                    end
                end
            end
            9: begin  // '6' → 页3
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("6");
                    wait_cnt = 0; phase = 10;
                end
            end
            10: begin  // 等 STATUS_PAGE==3 且画完
                if (u_top.u_ram_top.ram_sec_1.mem[16'h437] == 3) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (nw > base_nw + 800 && stable > 300000) begin
                        $display("== STATUS 页3 画完 @%0d nw=%0d ==", cyc, nw);
                        $display("  FB 行0 col6-11(页标题'GPIO'字形): %02X %02X %02X %02X %02X %02X",
                            u_top.u_ram_top.ram_sec_1.mem[16'h006], u_top.u_ram_top.ram_sec_1.mem[16'h007],
                            u_top.u_ram_top.ram_sec_1.mem[16'h008], u_top.u_ram_top.ram_sec_1.mem[16'h009],
                            u_top.u_ram_top.ram_sec_1.mem[16'h00A], u_top.u_ram_top.ram_sec_1.mem[16'h00B]);
                        wait_cnt = 0; phase = 11;
                    end
                end
            end
            11: begin  // '4' → 回页2
                wait_cnt = wait_cnt + 1;
                if (wait_cnt > 10000) begin
                    inject_key("4");
                    wait_cnt = 0; phase = 12;
                end
            end
            12: begin  // 等 STATUS_PAGE==2 且画完
                if (u_top.u_ram_top.ram_sec_1.mem[16'h437] == 2) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (nw > base_nw + 800 && stable > 300000) begin
                        $display("== '4' 返回页2 画完 @%0d == PASS ==", cyc);
                        $finish;
                    end
                end
                else if (cyc > 12000000) begin $display("!! '4' 超时"); $finish; end
            end
        endcase
        if (freeze > 3000000) begin
            $display("!! PC 冻结 %0d 拍 @cyc=%0d pc=%04X —— 疑似挂死", freeze, cyc, last_pc);
            $finish;
        end
        if (cyc % 1000000 == 0) $display("T%0d cyc=%0d nw=%0d MENU=%0d SEL=%0d SP=%0d pc=%04X",
            cyc, cyc, nw,
            u_top.u_ram_top.ram_sec_2.mem[16'h11C], u_top.u_ram_top.ram_sec_1.mem[16'h433],
            u_top.u_ram_top.ram_sec_1.mem[16'h437], last_pc);
    end

    integer di;
    initial begin
        repeat(12000000) @(posedge clk);
        $display("=== END @%0d nw=%0d ===", cyc, nw);
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
        force u_top.u_uart.tx_busy = 1'b0;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
