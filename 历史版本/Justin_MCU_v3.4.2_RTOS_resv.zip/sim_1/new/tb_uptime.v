`timescale 1ns / 1ps
// tb_uptime — 定位 UPTIME 刷新：进 STATUS 页0 → 强制 UPTIME_S0=65 → 触发刷新
//   检查 FB 行2 内容和 oled_flush 上传的列范围（是否覆盖秒数）
module tb_uptime;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    pullup (gpio_pin_bus[4]); pullup (gpio_pin_bus[5]);
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus));
    always #10 clk = ~clk;

    wire scl = gpio_pin_bus[4]; wire sda = gpio_pin_bus[5];
    reg prev_scl = 1, prev_sda = 1;
    integer ack_cnt = 0;
    always @(posedge clk) begin
        if (scl && !prev_scl) begin
            ack_cnt = ack_cnt + 1;
            if ((ack_cnt % 9) == 0) force gpio_pin_bus[5] = 1'b0;
        end
        if (!scl && prev_scl) begin
            if ((ack_cnt % 9) == 0) release gpio_pin_bus[5];
        end
        prev_scl = scl; prev_sda = sda;
    end

    integer nw = 0;
    reg [7:0] stream [0:32767];
    reg [15:0] stream_addr [0:32767];
    always @(posedge clk) begin
        if (u_top.u_i2c_out.bus_addr_final[15:12] == 4'h1 && u_top.u_i2c_out.bus_sig_final[0] && nw < 32768) begin
            stream[nw] = u_top.u_i2c_out.bus_data_final;
            stream_addr[nw] = u_top.u_i2c_out.bus_addr_final;
            nw = nw + 1;
        end
    end

    integer cyc = 0;
    integer last_nw = 0, stable = 0;
    integer wait_cnt = 0;
    integer phase = 0;
    integer freeze = 0, last_pc = 0;
    integer base_nw = 0;

    always @(posedge clk) begin
        if (u_top.u_cpu.u_pc.pc_addr != last_pc) freeze = 0;
        else freeze = freeze + 1;
        last_pc = u_top.u_cpu.u_pc.pc_addr;
    end

    // 跳延时加速
    reg dly_hold = 0; reg [4:0] dly_cnt = 0;
    always @(posedge clk) begin
        if (dly_hold) begin
            if (dly_cnt == 5'd30) begin
                release u_top.u_cpu.u_pc.pc_addr;
                dly_hold = 0; dly_cnt = 0;
            end
            else dly_cnt = dly_cnt + 1;
        end
        else if (u_top.u_cpu.u_pc.pc_addr >= 16'h15CB && u_top.u_cpu.u_pc.pc_addr <= 16'h15D3) begin
            force u_top.u_cpu.u_pc.pc_addr = 13'h15D4;
            dly_hold = 1; dly_cnt = 0;
        end
    end

    task inject_key; input [7:0] k; begin
        base_nw = nw;
        u_top.u_ram_top.ram_sec_2.mem[16'h100] = k;
        u_top.u_ram_top.ram_sec_2.mem[16'h108] = 1;
        u_top.u_ram_top.ram_sec_2.mem[16'h109] = 0;
        $display("== 注入 '%c' @%0d ==", k, cyc);
    end endtask

    integer di;
    always @(posedge clk) begin
        cyc = cyc + 1;
        case (phase)
            0: begin
                if (nw > 1380) begin
                    if (nw != last_nw) stable = 0;
                    else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 300000) begin
                        $display("== 主菜单稳定 @%0d ==", cyc);
                        stable = 0; wait_cnt = 0; phase = 1;
                    end
                end
            end
            1: begin wait_cnt = wait_cnt + 1; if (wait_cnt > 10000) begin inject_key("2"); wait_cnt = 0; phase = 2; end end
            2: begin
                if (u_top.u_ram_top.ram_sec_1.mem[16'h433] == 1) begin
                    if (nw != last_nw) stable = 0; else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 200000) begin $display("== SEL=1 @%0d ==", cyc); wait_cnt = 0; phase = 3; end
                end
            end
            3: begin wait_cnt = wait_cnt + 1; if (wait_cnt > 10000) begin inject_key("5"); wait_cnt = 0; phase = 4; end end
            4: begin
                if (u_top.u_ram_top.ram_sec_2.mem[16'h11C] == 3) begin
                    if (nw != last_nw) stable = 0; else stable = stable + 1;
                    last_nw = nw;
                    if (nw > base_nw + 800 && stable > 300000) begin
                        $display("== STATUS 页0 画完 @%0d nw=%0d ==", cyc, nw);
                        // 强制 UPTIME_S0=65（1m5s）, LAST_UP_SEC=0 → 触发下一次刷新
                        u_top.u_ram_top.ram_sec_2.mem[16'h134] = 65;
                        u_top.u_ram_top.ram_sec_1.mem[16'h438] = 0;
                        $display("  [强制 UPTIME_S0=65, LAST_UP_SEC=0] 等刷新...");
                        base_nw = nw; wait_cnt = 0; stable = 0; phase = 5;
                    end
                end
            end
            5: begin  // 等刷新执行（LAST_UP_SEC 被写为 65 即刷新已跑完）
                if (u_top.u_ram_top.ram_sec_1.mem[16'h438] == 65) begin
                    if (nw != last_nw) stable = 0; else stable = stable + 1;
                    last_nw = nw;
                    if (stable > 200000) begin
                        $display("== 刷新完成 @%0d nw=%0d (新增 %0d 字节) ==", cyc, nw, nw - base_nw);
                        $display("  FB 行2 (0x8100) 前 20 字节 (cols 0-19):");
                        for (di = 0; di < 20; di = di + 1)
                            $write("%02X ", u_top.u_ram_top.ram_sec_1.mem[16'h100 + di]);
                        $write("\n");
                        $display("  FB 行2 cols 54-101 (0x8136-0x8165):");
                        for (di = 0; di < 48; di = di + 1)
                            $write("%02X ", u_top.u_ram_top.ram_sec_1.mem[16'h136 + di]);
                        $write("\n");
                        $display("  ==== 刷新后新增 stream 字节 (addr: val) ====");
                        for (di = base_nw; di < nw; di = di + 1)
                            if (stream_addr[di] == 16'h1000)
                                $display("    s[%0d]=%02X", di, stream[di]);
                        $finish;
                    end
                end
                else if (cyc > 9000000) begin $display("!! 刷新未发生"); $finish; end
            end
        endcase
        if (freeze > 3000000) begin
            $display("!! PC 冻结 %0d 拍 @cyc=%0d pc=%04X", freeze, cyc, last_pc);
            $finish;
        end
        if (cyc % 1000000 == 0) $display("T%0d cyc=%0d nw=%0d MENU=%0d SEL=%0d SP=%0d pc=%04X",
            cyc, cyc, nw,
            u_top.u_ram_top.ram_sec_2.mem[16'h11C], u_top.u_ram_top.ram_sec_1.mem[16'h433],
            u_top.u_ram_top.ram_sec_1.mem[16'h437], last_pc);
    end

    initial begin
        repeat(12000000) @(posedge clk);
        $display("=== END @%0d ===", cyc);
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
        force u_top.u_uart.tx_busy = 1'b0;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
