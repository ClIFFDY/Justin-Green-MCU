`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/10 00:36:53
// Design Name:
// Module Name: single_cpu_top_tb
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module single_cpu_top_tb();

    reg clk, rst;

    single_cpu_top u_single_cpu_top(
        .clk(clk),
        .rst(rst)
    );

    // 时钟：周�? 10ns
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // 复位：前 20ns 拉高；第一次停机（T~1015ns）后再复位一次，测试能否重启
    initial begin
        rst = 1;
        #20
        rst = 0;
        #1250
        rst = 1;
        #20
        rst = 0;
    end

    // 每个上升沿打印状态机 / PC / 指令 / 译码 / IR / ALU / 全部 17 个寄存器（r0~r16）
    always @(posedge clk) begin
        $display("T=%3t | stage=%b pc=%2d inst=%b | dec(op=%b a1=%b a2=%b a3=%b) | ir(op=%b a1=%b a2=%b w=%b) | rs1=%d rs2=%d alu=%d | r0=%d r1=%d r2=%d r3=%d r4=%d r5=%d r6=%d r7=%d r8=%d r9=%d r10=%d r11=%d r12=%d r13=%d r14=%d r15=%d r16=%d",
                 $time,
                 u_single_cpu_top.stage, u_single_cpu_top.pc_addr, u_single_cpu_top.inst,
                 u_single_cpu_top.op_temp, u_single_cpu_top.r1_temp, u_single_cpu_top.r2_temp, u_single_cpu_top.rd_temp1,
                 u_single_cpu_top.opcode, u_single_cpu_top.r1, u_single_cpu_top.r2, u_single_cpu_top.rd_temp2,
                 u_single_cpu_top.rs1_data, u_single_cpu_top.rs2_data, u_single_cpu_top.result,
                 u_single_cpu_top.u_reg_f.regs[0], u_single_cpu_top.u_reg_f.regs[1],
                 u_single_cpu_top.u_reg_f.regs[2], u_single_cpu_top.u_reg_f.regs[3],
                 u_single_cpu_top.u_reg_f.regs[4], u_single_cpu_top.u_reg_f.regs[5],
                 u_single_cpu_top.u_reg_f.regs[6], u_single_cpu_top.u_reg_f.regs[7],
                 u_single_cpu_top.u_reg_f.regs[8], u_single_cpu_top.u_reg_f.regs[9],
                 u_single_cpu_top.u_reg_f.regs[10], u_single_cpu_top.u_reg_f.regs[11],
                 u_single_cpu_top.u_reg_f.regs[12], u_single_cpu_top.u_reg_f.regs[13],
                 u_single_cpu_top.u_reg_f.regs[14], u_single_cpu_top.u_reg_f.regs[15],
                 u_single_cpu_top.u_reg_f.regs[16]);
    end

    initial begin
        #2500
        $display("simulation finished");
        $finish;
    end

endmodule
