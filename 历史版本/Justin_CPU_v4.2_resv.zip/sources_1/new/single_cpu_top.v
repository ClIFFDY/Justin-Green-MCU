`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 00:01:51
// Design Name: 
// Module Name: single_cpu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module single_cpu_top(
    input wire clk, rst,
    output wire [7:0] result,
    output wire [7:0] inst
    );

    wire [7:0] pc_addr;
    // wire [7:0] inst;
    wire [7:0] rs1_data, rs2_data, imm_temp, imm8;
    wire [7:0] bytmov;
    // wire [7:0] result;
    wire [7:0] rd_data;
    wire [5:0] op_temp, opcode;
    wire [5:0] r1_temp, r2_temp, rd_temp1, rd_temp2;
    wire [5:0] r1, r2, rd;
    wire [5:0] ra_fo, ra_ba;
    wire we_temp1, we_temp2, we, frz, jmpwe, jmpred;
    wire [1:0] stage, tail;

    fsm u_fsm(
        .clk(clk),
        .rst(rst),
        .frz(frz),
        .tail(tail),
        .stage(stage)
    );

    pc u_pc(
        .clk(clk),
        .rst(rst),
        .stage(stage),
        .opcode(op_temp),
        .pc_addr(pc_addr),
        .bytmov(bytmov),
        .ra_in(ra_ba),
        .ra(ra_fo),
        .jmpwe(jmpwe),
        .jmpred(jmpred)
        );

    ins_rom u_ins_rom(
        .addr(pc_addr), 
        .inst(inst),
        .tail(tail)
        );

    decoder u_decoder(
        .clk(clk),
        .rst(rst),
        .stage(stage),
        .inst_raw(inst),
        .addr1(r1_temp),
        .addr2(r2_temp),
        .rd(rd_temp1),
        .opcode(op_temp),
        .bytmov(bytmov),
        .imm8(imm_temp),
        .frz(frz),
        .we(we_temp1)
        );

    ir u_ir(
        .clk(clk),
        .we_in(we_temp1),
        .stage(stage),
        .op_in(op_temp),
        .addr1_in(r1_temp),
        .addr2_in(r2_temp),
        .rd_in(rd_temp1),
        .imm_in(imm_temp),
        .opcode(opcode),
        .addr1(r1),
        .addr2(r2),
        .imm8(imm8),
        .rd(rd_temp2),
        .we(we_temp2)
    );

    alu u_alu(
        .a(rs1_data),
        .b(rs2_data),
        .imm8(imm8),
        .opr(opcode),
        .result(result)
        );

    wreg u_wreg(
        .clk(clk),
        .we_in(we_temp2),
        .stage(stage),
        .result_in(result),
        .rd_in(rd_temp2),
        .rd_data(rd_data),
        .rd(rd),
        .we(we)
    );
    
    reg_f u_reg_f(
        .clk(clk), 
        .we(we), 
        .jmpwe(jmpwe),
        .jmpred(jmpred),
        .addr1(r1),
        .addr2(r2),
        .rd(rd),
        .r1_data(rs1_data),
        .r2_data(rs2_data),
        .rd_data(rd_data),
        .ra_in(ra_fo),
        .ra(ra_ba)
        );
    
endmodule

