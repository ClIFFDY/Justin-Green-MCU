`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: pc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pc(
    input wire clk, rst, 
    input wire [1:0] stage,
    input wire [5:0] opcode, ra_in,
    input wire [7:0] bytmov,
    output reg [7:0] pc_addr,
    output reg [5:0] ra,
    output reg jmpwe, jmpred
    );

    localparam [1:0] 
    IDLE = 2'b00, 
    FET = 2'b01, 
    NEX  = 2'b10;

    localparam [5:0] 
    LJAL  = 6'b00_1000,
    RJAL  = 6'b00_1001,
    JALR  = 6'b01_0011;
    
    always@(posedge clk or posedge rst) begin
        if (rst) begin 
            pc_addr <= 8'd0;
            ra <= 6'b0;
            jmpwe <= 1'b0;
            jmpred <= 1'b0;
        end
        else if (stage == FET) begin
            jmpwe <= 1'b0;
            jmpred <= 1'b0;
            pc_addr <= pc_addr + 1;
        end
        else if (stage == NEX) begin
            if (opcode == LJAL || opcode == RJAL) begin
                ra <= pc_addr;
                jmpwe <= 1'b1;
                case (opcode[0])
                1'b0: pc_addr <= pc_addr - bytmov;
                1'b1: pc_addr <= pc_addr + bytmov;
                endcase
            end
            if (opcode == JALR) begin
                jmpred <= 1'b1;
                pc_addr <= ra_in;
            end
        end
    end
endmodule
