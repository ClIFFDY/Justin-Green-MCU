`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:51:25
// Design Name: 
// Module Name: decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder(
    input wire clk, rst,
    input wire [1:0] stage,
    input wire [7:0] inst_raw,
    output reg [5:0] addr1, addr2, rd,
    output reg [5:0] opcode,
    output reg [7:0] imm8,
    output reg [7:0] bytmov,
    output reg frz, we
    );
   
    localparam [5:0]
    HALT  = 6'b00_0000,
    ADDI  = 6'b00_0001,
    ADD   = 6'b00_0010,
    SUBI  = 6'b00_0011,
    SUB   = 6'b00_0100,
    AND   = 6'b00_0101,
    OR    = 6'b00_0110,
    XOR   = 6'b00_0111,
    LJAL  = 6'b00_1000,
    RJAL  = 6'b00_1001,
    ANDI  = 6'b00_1010,
    ORI   = 6'b00_1011,
    XORI  = 6'b00_1100,
    SLL   = 6'b00_1101,
    SRL   = 6'b00_1110,
    SLLI  = 6'b00_1111,
    SRLI  = 6'b01_0000,
    SLTU  = 6'b01_0001,
    SLTIU = 6'b01_0010,
    JALR  = 6'b01_0011;

    localparam [1:0] 
    IDLE = 2'b00, 
    FET = 2'b01,  
    NEX = 2'b11;

    reg [5:0] bytmov_h;

    always@(posedge clk or posedge rst) begin
        if (rst) begin
            frz <= 1'b0;
            opcode <= 4'b0001;
            addr1 <= 4'b0;
            addr2 <= 4'b0;
            rd <= 4'b0;
        end
        else begin
            if (stage == FET) begin
                case (inst_raw[1:0])
                2'b00: begin
                    opcode <= inst_raw[7:2];
                end
                2'b01: begin
                    case(opcode)
                    LJAL, RJAL: bytmov_h <= inst_raw [7:2];
                    default: rd <= inst_raw[7:2];
                    endcase
                end
                2'b10: begin
                    addr1 <= inst_raw[7:2];
                end
                2'b11: begin
                    case(opcode)
                    ADD, SUB, AND, OR, XOR, SLL, SRL, SLTU: begin
                        addr2 <= inst_raw[7:2];
                        imm8 <= 8'b0;
                        we <= 1'b1;
                    end
                    ADDI, SUBI, ANDI, ORI, XORI, SLLI, SRLI, SLTIU: begin
                        addr2 <= 6'b0;
                        imm8 <= inst_raw[7:2];
                        we <= 1'b1;
                    end
                    LJAL, RJAL: begin
                        bytmov <= {bytmov_h, inst_raw[7:6]};
                        we <= 1'b0;                       
                    end
                    JALR: begin
                        we <= 1'b0;
                    end
                    HALT: begin
                        frz <= 1'b1;
                        we <= 1'b0;
                    end
                    endcase
                end
                endcase
            end
        end
    end
endmodule
