`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:49:40
// Design Name: 
// Module Name: fsm
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsm(
    input wire clk, rst, frz,
    input wire [1:0] tail,
    output reg [1:0] stage
    );
    
    localparam [1:0] 
    IDLE = 2'b00, 
    FET = 2'b01, 
    NEX  = 2'b10;

    always @(posedge clk or posedge rst) begin
        if (rst) begin 
            stage <= FET;
        end
        else begin
            case (stage)
            IDLE: begin
                if (!frz) begin
                    stage <= FET;   
                end 
            end
            FET: begin 
                if (tail == 2'b11) stage <= NEX;
            end
            NEX: begin 
                if (frz) begin 
                    stage <= IDLE;
                end
                else stage <= FET;
            end
            default: stage <= IDLE;
            endcase
        end
    end
endmodule
