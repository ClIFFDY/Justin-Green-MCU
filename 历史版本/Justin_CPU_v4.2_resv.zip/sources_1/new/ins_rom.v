`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/09 22:05:38
// Design Name:
// Module Name: ins_rom
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module ins_rom(
    input wire [7:0] addr,
    output wire [7:0] inst,
    output wire [1:0] tail
    );

    reg[7:0] mem [0:255];

    integer i;

    initial begin

        for (i = 0; i < 256; i = i + 1) mem[i] = 8'd0;

        // ============ 两层嵌套调用/返回测试 ============
        // 验证：返回地址栈 LIFO 顺序（sub2 先返回 39 → sub1 再返回 3）
        //
        // 主程序  mem[0..2]   RJAL → 32         入栈{3}，跳过 mem[3..14]
        //         mem[3..14]  ADDI r1,r2,r3     （返回后执行）
        //         mem[15..16] HALT
        // sub1    mem[32..35] ADDI r4
        //         mem[36..38] RJAL → 48        入栈{39}
        //         mem[39..41] JALR             出栈{39} → 返 39（回到 sub1 剩余代码）
        // sub2    mem[48..51] ADDI r5
        //         mem[52..54] JALR             出栈{3} → 返 3（回主程序）

        // ---- 主程序 ----
        // RJAL → 32（bytmov = 29 = {bytmov_h=000111, 低2位=01}）
        mem[0] = 8'b001001_00;  // opcode = RJAL
        mem[1] = 8'b000111_01;  // bytmov_h = 000111
        mem[2] = 8'b010000_11;  // bytmov 低2位 = 01，tag 11

        // ADDI r1 = r1 + 1
        mem[3] = 8'b000001_00;  // opcode = ADDI
        mem[4] = 8'b000001_01;  // rd = r1
        mem[5] = 8'b000001_10;  // addr1 = r1
        mem[6] = 8'b000001_11;  // imm8 = 1

        // ADDI r2 = r2 + 2
        mem[7] = 8'b000001_00;  // opcode = ADDI
        mem[8] = 8'b000010_01;  // rd = r2
        mem[9] = 8'b000010_10;  // addr1 = r2
        mem[10] = 8'b000010_11; // imm8 = 2

        // ADDI r3 = r3 + 3
        mem[11] = 8'b000001_00; // opcode = ADDI
        mem[12] = 8'b000011_01; // rd = r3
        mem[13] = 8'b000011_10; // addr1 = r3
        mem[14] = 8'b000011_11; // imm8 = 3

        // HALT（2 字节）
        mem[15] = 8'b000000_00; // opcode = HALT
        mem[16] = 8'b000000_11; // tag 11

        // ---- sub1：入口 32 ----
        // ADDI r4 = r4 + 4
        mem[32] = 8'b000001_00; // opcode = ADDI
        mem[33] = 8'b000100_01; // rd = r4
        mem[34] = 8'b000100_10; // addr1 = r4
        mem[35] = 8'b000100_11; // imm8 = 4

        // RJAL → 48（bytmov = 9 = {bytmov_h=000010, 低2位=01}）
        mem[36] = 8'b001001_00; // opcode = RJAL
        mem[37] = 8'b000010_01; // bytmov_h = 000010
        mem[38] = 8'b010000_11; // bytmov 低2位 = 01，tag 11

        // JALR：出栈返回 sub1（返回地址 39）
        mem[39] = 8'b010011_00; // opcode = JALR
        mem[40] = 8'b000000_01; // byte1 任意（tag 01）
        mem[41] = 8'b000000_11; // tag 11

        // ---- sub2：入口 48 ----
        // ADDI r5 = r5 + 5
        mem[48] = 8'b000001_00; // opcode = ADDI
        mem[49] = 8'b000101_01; // rd = r5
        mem[50] = 8'b000101_10; // addr1 = r5
        mem[51] = 8'b000101_11; // imm8 = 5

        // JALR：出栈返回 sub1（返回地址 39）
        mem[52] = 8'b010011_00; // opcode = JALR
        mem[53] = 8'b000000_01; // byte1 任意（tag 01）
        mem[54] = 8'b000000_11; // tag 11

    end

    assign inst = mem[addr];
    assign tail = mem[addr][1:0];

endmodule

    // localparam [5:0]
    // HALT  = 6'b00_0000,
    // ADDI  = 6'b00_0001,
    // ADD   = 6'b00_0010,
    // SUBI  = 6'b00_0011,
    // SUB   = 6'b00_0100,
    // AND   = 6'b00_0101,
    // OR    = 6'b00_0110,
    // XOR   = 6'b00_0111,
    // LJAL  = 6'b00_1000,
    // RJAL  = 6'b00_1001,
    // ANDI  = 6'b00_1010,
    // ORI   = 6'b00_1011,
    // XORI  = 6'b00_1100,
    // SLL   = 6'b00_1101,
    // SRL   = 6'b00_1110,
    // SLLI  = 6'b00_1111,
    // SRLI  = 6'b01_0000,
    // SLTU  = 6'b01_0001,
    // SLTIU = 6'b01_0010,
    // JALR  = 6'b01_0011;
