`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: reg_f
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module reg_f(
    input wire clk,
    input wire we, jmpwe, jmpred,
    input wire [5:0] addr1, addr2, rd, ra_in,
    input wire [7:0] rd_data,
    output wire [5:0] ra,
    output wire [7:0] r1_data, r2_data
    );

    wire [5:0] r1, r2;

    reg [7:0] regs [0:63];
    reg [7:0] rad [0:15];

    integer i;
    reg [3:0] j;

    assign r1 = addr1;
    assign r2 = addr2;
    assign r1_data = (r1 == 4'b0) ? 0 : regs[r1];
    assign r2_data = (r2 == 4'b0) ? 0 : regs[r2];

    initial begin
        for (i = 0; i < 64; i = i + 1) regs[i] = 8'd0;
        for (i = 0; i < 16; i = i + 1) rad[i] = 8'd0;
        j = 4'b0;
    end

    // ra = 返回地址栈栈顶，组合输出，供 pc 的 JALR 一拍读到（不被时钟清零）
    assign ra = rad[j - 1];

    always @(posedge clk) begin
        if (we && rd != 0) regs[rd] <= rd_data;
        if (jmpwe && ra_in != 0) begin
            rad[j] <= ra_in;
            j <= j + 1;
        end
        else if (jmpred && j != 4'b0) begin
            rad[j - 1] <= 6'b0;
            j <= j - 1;
        end
    end
endmodule
