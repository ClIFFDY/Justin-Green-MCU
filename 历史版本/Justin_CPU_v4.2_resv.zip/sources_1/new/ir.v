`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 02:43:51
// Design Name: 
// Module Name: ir
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ir(
    input wire clk, we_in,
    input wire [1:0] stage,
    input wire [5:0] op_in, addr1_in, addr2_in, rd_in,
    input wire [7:0] imm_in,
    output reg [5:0] opcode, addr1, addr2, rd,
    output reg [7:0] imm8,
    output reg we
    );

    always@(posedge clk) begin
        if (stage == 2'b10) begin
            opcode <= op_in;
            addr1 <= addr1_in;
            addr2 <= addr2_in;
            imm8 <= imm_in;
            rd <= rd_in;
            we <= we_in;
        end
    end
endmodule
