`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: reg_f
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module reg_f(
    input wire clk, rst, stall,
    input wire we, tx_busy,
    input wire [1:0] jmpflg,
    input wire [23:0] addr_r12,
    input wire [7:0] rd,
    input wire [11:0] ra_in,
    input wire [7:0] rd_data,
    output reg [1:0] j_flag,
    output reg [11:0] ra,
    output reg [23:0] rd12_data
    );

    reg [7:0] regs [0:255];
    (* ram_style = "block" *) reg [15:0] rad [0:255];

    
    integer i;
    initial begin
        for (i = 0; i < 64; i = i + 1) regs[i] = 8'b0;
        for (i = 0; i < 16; i = i + 1) rad[i] = 8'b0;
    end

    always @(posedge clk) begin
        j_flag[1] <= (regs[254] == 8'd255) ? 1'b1 : 1'b0;
        j_flag[0] <= (regs[254] == 8'b0) ? 1'b1 : 1'b0;
        if (!stall) begin
            rd12_data[23:16] <= (addr_r12[23:16] == rd && we) ? rd_data : regs[addr_r12[23:16]];
            rd12_data[15:8] <= (addr_r12[15:8] == rd && we) ? rd_data : regs[addr_r12[15:8]];
            rd12_data[7:0] <= (addr_r12[7:0] == rd && we) ? rd_data : regs[addr_r12[7:0]];
        end
        else rd12_data <= rd12_data;
    end

    always @(posedge clk) begin
        if (rst) begin 
            ra <= 12'b0;
            regs[254] <= 8'b0;
        end
        else begin
            ra <= rad[regs[254] - 1];
            regs[255] <= {7'b0, tx_busy};
            if (we && rd != 0) regs[rd] <= rd_data;

            if (jmpflg[1] && ra_in != 0) begin
                rad[regs[254]] <= ra_in;      
                regs[254] <= regs[254] + 1;
            end
            else if (jmpflg[0] && regs[254] != 9'b0) begin
                rad[regs[254] - 1] <= 9'b0;
                regs[254] <= regs[254] - 1;
            end
        end
    end
endmodule
