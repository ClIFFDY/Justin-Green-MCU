`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:51:25
// Design Name: 
// Module Name: decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder(
    input wire [31:0] inst_raw,
    input wire rst,
    output reg [7:0] addr1, addr2, rd,
    output wire [5:0] opcode,
    output reg [7:0] imm8,
    output reg [7:0] bytmov,
    output reg frz, we
    );
   
    localparam [5:0]
    HALT  = 6'b00_0000,
    ADDI  = 6'b00_0001,
    ADD   = 6'b00_0010,
    SUBI  = 6'b00_0011,
    SUB   = 6'b00_0100,
    AND   = 6'b00_0101,
    OR    = 6'b00_0110,
    XOR   = 6'b00_0111,
    LJAL  = 6'b00_1000,
    RJAL  = 6'b00_1001,
    ANDI  = 6'b00_1010,
    ORI   = 6'b00_1011,
    XORI  = 6'b00_1100,
    SLL   = 6'b00_1101,
    SRL   = 6'b00_1110,
    SLLI  = 6'b00_1111,
    SRLI  = 6'b01_0000,
    SLTU  = 6'b01_0001,
    SLTIU = 6'b01_0010,
    JALR  = 6'b01_0011;

    assign opcode = inst_raw[31:26];

    always @(*) begin
        case (inst_raw[31:26])
        LJAL, RJAL: begin
            bytmov = inst_raw[23:16];
            we = 1'b0;
        end
        ADD, SUB, AND, OR, XOR, SLL, SRL, SLTU: begin
            rd = inst_raw[23:16];
            addr1 = inst_raw[15:8];
            addr2 = inst_raw[7:1];
            we = 1'b1;
        end
        ADDI, SUBI, ANDI, ORI, XORI, SLLI, SRLI, SLTIU: begin
            rd = inst_raw[23:16];
            addr1 = inst_raw[15:8];
            imm8 = inst_raw[7:0];
            we = 1'b1;
        end
        JALR: begin
            we = 1'b0;
        end
        HALT: begin
            if (!rst) frz = 1'b1;
        end
        default: begin
            bytmov = 8'b0;
            addr1 = 8'b0;
            addr2 = 8'b0;
            rd = 8'b0;
            imm8 = 8'b0;
            frz = 1'b0;
            we = 1'b0;
        end
        endcase
        if (rst) begin
            bytmov = 8'b0;
            addr1 = 8'b0;
            addr2 = 8'b0;
            rd = 8'b0;
            imm8 = 8'b0;
            frz = 1'b0;
            we = 1'b0;
        end
    end
endmodule
