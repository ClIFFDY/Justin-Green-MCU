`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/11 11:09:39
// Design Name: 
// Module Name: wreg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module wreg(
    input wire clk, we_in,
    input wire [2:0] stage,
    input wire [7:0] result_in,
    input wire [7:0] rd_in,
    output reg [7:0] rd_data,
    output reg [7:0] rd,
    output reg we
    );

    localparam WRT = 3'b100;

    always @(posedge clk) begin
        if(stage == WRT) begin
            rd_data <= result_in;
            rd <= rd_in;
            we <= we_in;
        end
        else begin
            rd_data <= 8'b0;
            rd <= 8'b0;
            we <= 1'b0;
        end
    end

endmodule
