`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:49:40
// Design Name: 
// Module Name: fsm
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsm(
    input wire clk, rst, frz,
    output reg [2:0] stage
    );
    
    localparam [2:0] 
    IDLE = 3'b000, 
    IF = 3'b001,
    // ID = 3'b010,
    OPR = 3'b011,
    WRT = 3'b100;

    always @(posedge clk or posedge rst) begin
        if (rst) begin 
            stage <= IF;
        end
        else begin
            case (stage)
            IDLE: begin
                if (!frz) begin
                    stage <= IF;   
                end 
            end
            IF: begin 
                stage <= OPR;
            end
            OPR: begin 
                if (frz) begin 
                    stage <= IDLE;
                end
                else stage <= WRT;
            end
            WRT: begin
                stage <= IF;
            end
            default: stage <= IDLE;
            endcase
        end
    end
endmodule
