    RJAL  32          
    ADDI  r1, r1, 1
    ADDI  r2, r2, 2
    ADDI  r3, r3, 3
    HALT              

    .org  32          
    ADDI  r4, r4, 4
    RJAL  48          
    JALR             

    .org  48         
    ADDI  r5, r5, 5
    JALR              