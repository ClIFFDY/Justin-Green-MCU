#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
asm.py —— v5.0 单周期 CPU 汇编器（绝对地址式）

把助记符写法的 .asm 转成 tb 用 $readmemh 载入的 ins_rom.hex：
    python asm.py example.asm              # 输出 <输入目录>/ins_rom.hex
    python asm.py example.asm -o out.hex   # 自定义输出路径

编码规则（与 decoder.v / pc.v 一致）：
    opcode 字节 = opcode[5:0] << 2 | len[1:0]，len = 字节数 - 1
      HALT = 00_0000   (1B, len=00)
      LJAL = 00_1000 / RJAL = 00_1001 / JALR = 01_0011   (2B, len=01)
      ALU-R（ADD SUB AND OR XOR SLL SRL SLTU）：byte1=rd, byte2=rs1, byte3=rs2
      ALU-I（ADDI SUBI ANDI ORI XORI SLLI SRLI SLTIU）：byte1=rd, byte2=rs1, byte3=imm8
      ALU 4B, len=11
    跳转偏移 bytmov（8-bit 无符号，方向由 opcode[0] 决定）：
      RJAL：bytmov = 目标 - (pc+2)；LJAL：bytmov = (pc+2) - 目标；均须 0..255

语法：
    HALT                        # 停机
    RJAL 32  /  LJAL 0x10       # 绝对地址跳转，bytmov 自动算
    JALR                        # 出栈返回
    ADD  r1, r2, r3             # rd=r1, rs1=r2, rs2=r3
    ADDI r1, r1, 0x1F           # rd=r1, rs1=r1, imm=31
    .org 32                     # 伪指令：设置当前地址（放子程序用）
    注释：# 或 // 开头
    寄存器可写 r1 / R1 / 裸数字 1；立即数/地址可写十进制或 0x 十六进制（也支持 0b 二进制）
"""

import argparse
import os
import sys

# 助记符 -> (opcode_6bit, 字节数, 操作数格式)
# 格式: 'none' 无操作数 | 'tgt' 一个绝对地址 | 'rrr' rd,rs1,rs2 | 'rri' rd,rs1,imm8
INSTR = {
    'halt':  (0b000000, 1, 'none'),
    'addi':  (0b000001, 4, 'rri'),
    'add':   (0b000010, 4, 'rrr'),
    'subi':  (0b000011, 4, 'rri'),
    'sub':   (0b000100, 4, 'rrr'),
    'and':   (0b000101, 4, 'rrr'),
    'or':    (0b000110, 4, 'rrr'),
    'xor':   (0b000111, 4, 'rrr'),
    'ljal':  (0b001000, 2, 'tgt'),
    'rjal':  (0b001001, 2, 'tgt'),
    'andi':  (0b001010, 4, 'rri'),
    'ori':   (0b001011, 4, 'rri'),
    'xori':  (0b001100, 4, 'rri'),
    'sll':   (0b001101, 4, 'rrr'),
    'srl':   (0b001110, 4, 'rrr'),
    'slli':  (0b001111, 4, 'rri'),
    'srli':  (0b010000, 4, 'rri'),
    'sltu':  (0b010001, 4, 'rrr'),
    'sltiu': (0b010010, 4, 'rri'),
    'jalr':  (0b010011, 2, 'none'),
}

REQ = {'none': 0, 'tgt': 1, 'rrr': 3, 'rri': 3}


def strip_comment(line):
    """去掉 # 和 // 注释（跳过单引号字符字面量，避免 '//'、'#'、' ' 被误伤）。"""
    in_quote = False
    i = 0
    while i < len(line):
        c = line[i]
        if c == "'":
            in_quote = not in_quote
        elif not in_quote:
            if c == '#':
                return line[:i]
            if c == '/' and i + 1 < len(line) and line[i + 1] == '/':
                return line[:i]
        i += 1
    return line


def tokenize(line):
    """按空格/逗号切分；单引号字符字面量（含 ' '）作为整体。"""
    toks = []
    cur = ''
    i = 0
    n = len(line)
    while i < n:
        c = line[i]
        if c == "'":
            cur += c
            i += 1
            while i < n and line[i] != "'":
                cur += line[i]
                i += 1
            if i < n:
                cur += line[i]  # 闭合引号
                i += 1
        elif c in ', \t':
            if cur:
                toks.append(cur)
                cur = ''
            i += 1
        else:
            cur += c
            i += 1
    if cur:
        toks.append(cur)
    return toks


def parse_int(s, what='数字'):
    """十进制 / 0x 十六进制 / 0b 二进制 / '单字符'，均可；支持前导零的十进制。"""
    t = s.strip()
    # 单字符字面量，如 'H'、' ' -> ASCII 码
    if len(t) == 3 and t[0] == "'" and t[2] == "'":
        return ord(t[1])
    try:
        low = t[:2].lower()
        if low == '0x':
            return int(t[2:], 16)
        if low == '0b':
            return int(t[2:], 2)
        return int(t, 10)
    except ValueError:
        raise ValueError(f"{what} 必须是数字或字符：'{s}'（十进制 / 0x 十六进制 / '字符'）")


def parse_reg(s):
    """寄存器：r1 / R1 / 裸数字 1。"""
    t = s.strip()
    if t[:1].lower() == 'r':
        if not t[1:].isdigit():
            raise ValueError(f"寄存器写法错误：'{s}'，应为 r<数字>")
        return int(t[1:])
    return parse_int(t, '寄存器号')


def chk_reg(v):
    if not 0 <= v <= 255:
        raise ValueError(f"寄存器号越界：{v}（须 0..255）")


def assemble(lines):
    """逐行汇编，返回 (mem, listing)。mem 为 {地址:字节}；出错时 errors 收集。"""
    mem = {}
    listing = []
    errors = []
    addr = 0
    max_written = 0  # 已写入的最高字节地址 + 1

    for lineno, raw in enumerate(lines, 1):
        # 去注释（# 或 //）与空白；切词时保留 '字符' 字面量
        line = strip_comment(raw).strip()
        if not line:
            continue
        toks = tokenize(line)
        if not toks:
            continue
        tok0 = toks[0].lower()

        if tok0 == '.org':
            if len(toks) != 2:
                errors.append((lineno, ".org 需要 1 个地址参数"))
                continue
            try:
                new_addr = parse_int(toks[1], '.org 地址')
            except ValueError as e:
                errors.append((lineno, str(e)))
                continue
            if not 0 <= new_addr <= 255:
                errors.append((lineno, f".org 地址越界：{new_addr}（须 0..255）"))
                continue
            if new_addr < max_written:
                errors.append((lineno, f".org {new_addr} 落在已写区域（最高到 0x{max_written - 1:02X}），会覆盖已有字节"))
                continue
            listing.append((new_addr, '', f".org {new_addr}"))
            addr = new_addr
            continue

        if tok0 not in INSTR:
            errors.append((lineno, f"未知助记符：'{toks[0]}'"))
            continue
        op, nbytes, fmt = INSTR[tok0]
        operands = toks[1:]

        if len(operands) != REQ[fmt]:
            errors.append((lineno, f"{toks[0].upper()} 需要 {REQ[fmt]} 个操作数，实际 {len(operands)} 个"))
            continue

        try:
            if fmt == 'tgt':
                target = parse_int(operands[0], '跳转目标地址')
                if not 0 <= target <= 255:
                    raise ValueError(f"跳转目标越界：{target}（须 0..255）")
                pc_after = addr + nbytes  # 即 pc + len + 1
                if tok0 == 'rjal':
                    bytmov = target - pc_after
                    if bytmov < 0:
                        raise ValueError(f"RJAL 目标 {target} 在指令后方，应改用 LJAL")
                else:  # ljal
                    bytmov = pc_after - target
                    if bytmov < 0:
                        raise ValueError(f"LJAL 目标 {target} 在指令前方，应改用 RJAL")
                if not 0 <= bytmov <= 255:
                    raise ValueError(f"bytmov={bytmov} 超出 8 位范围（0..255）")
                body = [op << 2 | (nbytes - 1), bytmov]
            elif fmt == 'rrr':
                rd = parse_reg(operands[0]); chk_reg(rd)
                rs1 = parse_reg(operands[1]); chk_reg(rs1)
                rs2 = parse_reg(operands[2]); chk_reg(rs2)
                body = [op << 2 | (nbytes - 1), rd, rs1, rs2]
            elif fmt == 'rri':
                rd = parse_reg(operands[0]); chk_reg(rd)
                rs1 = parse_reg(operands[1]); chk_reg(rs1)
                imm = parse_int(operands[2], '立即数')
                if not 0 <= imm <= 255:
                    raise ValueError(f"立即数越界：{imm}（须 0..255）")
                body = [op << 2 | (nbytes - 1), rd, rs1, imm]
            else:  # none（HALT 1B / JALR 2B：len=00/01，JALR 的 byte1 为预留槽 0x00）
                body = [op << 2 | (nbytes - 1)] + [0] * (nbytes - 1)
        except ValueError as e:
            errors.append((lineno, str(e)))
            continue

        if addr + nbytes > 256:
            errors.append((lineno, f"{toks[0].upper()} 超出 ins_rom 空间（地址 0x{addr:02X} + {nbytes} 字节 > 256）"))
            continue

        for i, b in enumerate(body):
            mem[addr + i] = b
        max_written = max(max_written, addr + nbytes)
        listing.append((addr, ' '.join(f'{b:02X}' for b in body),
                        ' '.join(toks).upper() if fmt != 'none' else toks[0].upper()))
        addr += nbytes

    return mem, listing, errors


def write_hex(mem, out_path, src_name):
    """按连续区段写 $readmemh 兼容的 hex（@XXXX 块 + 空格分隔字节）。"""
    addrs = sorted(mem)
    with open(out_path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(f'// ins_rom.hex —— 由 asm.py 从 {src_name} 生成（供 tb $readmemh 载入）\n')
        i = 0
        while i < len(addrs):
            start = addrs[i]
            j = i
            while j + 1 < len(addrs) and addrs[j + 1] == addrs[j] + 1:
                j += 1
            f.write(f'@{start:04X}\n')
            f.write(' '.join(f'{mem[a]:02X}' for a in addrs[i:j + 1]) + '\n')
            i = j + 1


def main(argv):
    # Windows 控制台默认 GBK，强制 UTF-8 避免中文乱码
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description='v5.0 CPU 汇编器：.asm → ins_rom.hex')
    parser.add_argument('input', help='.asm 源文件')
    parser.add_argument('-o', '--output', help='输出 hex 文件（默认 <输入目录>/ins_rom.hex）')
    args = parser.parse_args(argv)

    try:
        with open(args.input, 'r', encoding='utf-8') as f:
            lines = f.read().splitlines()
    except OSError as e:
        print(f'错误：无法读取 {args.input}：{e}', file=sys.stderr)
        return 1

    mem, listing, errors = assemble(lines)

    if errors:
        for lineno, msg in errors:
            print(f'错误 行{lineno}: {msg}', file=sys.stderr)
        print(f'共 {len(errors)} 个错误，未生成输出文件。', file=sys.stderr)
        return 1

    if not mem:
        print('错误：源文件里没有任何指令（或全被注释掉了）。', file=sys.stderr)
        return 1

    # listing（地址 | 机器码 | 源）
    print(f'地址   机器码                   | 源')
    for a, b, s in listing:
        bar = '---' if not b else '   '
        print(f'{a:04X}:  {b:<22} {bar} {s}')

    out_path = args.output or os.path.join(os.path.dirname(os.path.abspath(args.input)), 'ins_rom.hex')
    write_hex(mem, out_path, os.path.basename(args.input))
    print(f'\n成功：{len(mem)} 字节写入 {out_path}（最高地址 0x{max(mem):02X}）')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
