`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: pc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pc(
    input wire clk, rst, frz,
    input wire stage,
    input wire [1:0] inst_num,
    input wire [5:0] op_raw,
    input wire [7:0] bytmov, ra_in,
    output reg [7:0] pc_addr,
    output reg [7:0] ra,
    output reg jmpwe, jmpred
    );

    localparam  
    IDLE = 1'b0, 
    EXE = 1'b1;

    localparam [5:0] 
    LJAL  = 6'b00_1000,
    RJAL  = 6'b00_1001,
    JALR  = 6'b01_0011;
    
    always @(posedge clk or posedge rst) begin
        if (rst) begin 
            pc_addr <= 8'b0;
            ra <= 8'b0;
            jmpwe <= 1'b0;
            jmpred <= 1'b0;
        end
        else if (stage == EXE) begin
            jmpwe <= 1'b0;
            jmpred <= 1'b0;
            case (op_raw)
            LJAL, RJAL: begin 
                ra <= pc_addr;
                jmpwe <= 1'b1;
                case (op_raw[0])
                    1'b0: pc_addr <= pc_addr - bytmov;
                    1'b1: pc_addr <= pc_addr + bytmov;
                endcase
            end 
            JALR: begin
                jmpred <= 1'b1;
                pc_addr <= ra_in;
            end
            default: begin
                if(!frz) begin
                    pc_addr <= pc_addr + inst_num + 1;
                end
            end
            endcase
        end
    end
endmodule
