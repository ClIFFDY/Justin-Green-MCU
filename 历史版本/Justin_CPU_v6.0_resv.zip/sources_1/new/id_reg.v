`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/12 00:18:11
// Design Name: 
// Module Name: id_reg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module id_reg(
    input wire clk, we_in, stage, flush_in,
    input wire [5:0] op_in, 
    input wire [7:0] addr1_in, addr2_in, rd_in,
    input wire [7:0] imm_in,
    output reg [5:0] opcode,
    output reg [7:0] addr1, addr2, rd,
    output reg [7:0] imm8,
    output reg we, flush2
    );

    always@(posedge clk) begin
        if (stage == 1'b1) begin
            if (!flush_in) begin
                opcode <= op_in;
                addr1 <= addr1_in;
                addr2 <= addr2_in;
                imm8 <= imm_in;
                rd <= rd_in;
                we <= we_in;
                flush2 <= 1'b0;
            end
            else begin
                opcode <= op_in;
                addr1 <= 8'b0;
                addr2 <= 8'b0;
                imm8 <= 8'b0;
                rd <= 8'b0;
                we <= 1'b0;
                flush2 <= 1'b1;
            end
        end
    end
endmodule
