`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 00:01:51
// Design Name: 
// Module Name: single_cpu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module single_cpu_top(
    input wire clk, rst
    );

    wire stage;
    wire [7:0] pc_addr;
    wire [31:0] inst_raw1, inst_raw2;
    wire [1:0] inst_num;
    wire [5:0] op_temp, opcode;
    wire [7:0] r1_temp, r2_temp, r1, r2, rd_temp1, rd_temp2, rd;
    wire [7:0] r1_data, r2_data, rd_data, imm_temp, imm8;
    wire [7:0] bytmov;
    wire [7:0] ra_fo, ra_ba;
    wire [7:0] result;
    wire we_temp1, we_temp2, we, jmpwe, jmpred;
    wire frz, flush1, flush2;

    fsm u_fsm(
        .clk(clk),
        .rst(rst),
        .frz(frz),
        .stage(stage)
    );

    pc u_pc(
        .clk(clk),
        .rst(rst),
        .stage(stage),
        .inst_num(inst_num),
        .op_raw(op_temp),
        .bytmov(bytmov),
        .frz(frz),
        .ra_in(ra_ba),
        .pc_addr(pc_addr),
        .ra(ra_fo),
        .jmpwe(jmpwe),
        .jmpred(jmpred)
        );

    ins_rom u_ins_rom(
        .addr(pc_addr),
        .inst_raw(inst_raw1),
        .inst_num(inst_num)
        );
    
    if_reg u_if_reg(
        .clk(clk),
        .flush_raw(flush1),
        .stage(stage),
        .rst(rst),
        .inst_raw_in(inst_raw1),
        .inst_raw(inst_raw2)
    );

    decoder u_decoder(
        .inst_raw(inst_raw2),
        .rst(rst),
        .addr1(r1_temp),
        .addr2(r2_temp),
        .rd(rd_temp1),
        .opcode(op_temp),
        .bytmov(bytmov),
        .imm8(imm_temp),
        .frz(frz),
        .we(we_temp1),
        .flush1(flush1)
        );

    id_reg u_id_reg(
        .clk(clk),
        .we_in(we_temp1),
        .stage(stage),
        .flush_in(flush1),
        .op_in(op_temp),
        .addr1_in(r1_temp),
        .addr2_in(r2_temp),
        .rd_in(rd_temp1),
        .imm_in(imm_temp),
        .opcode(opcode),
        .addr1(r1),
        .addr2(r2),
        .rd(rd_temp2),
        .imm8(imm8),
        .we(we_temp2),
        .flush2(flush2)
    );

    alu u_alu(
        .a(r1_data),
        .b(r2_data),
        .imm8(imm8),
        .opr(opcode),
        .result(result)
        );

    wr_reg u_wr_reg(
        .clk(clk),
        .we_in(we_temp2),
        .stage(stage),
        .flush2(flush2),
        .result_in(result),
        .rd_in(rd_temp2),
        .rd_data(rd_data),
        .rd(rd),
        .we(we)
    );
    
    reg_f u_reg_f(
        .clk(clk), 
        .we(we), 
        .jmpwe(jmpwe),
        .jmpred(jmpred),
        .addr1(r1),
        .addr2(r2),
        .rd(rd),
        .ra_in(ra_fo),
        .ra(ra_ba),
        .r1_data(r1_data),
        .r2_data(r2_data),
        .rd_data(rd_data)
        );
    
endmodule

