# ============================================================
# 引脚约束 + 时钟约束
# 目标器件：MicroPhase Z-7 Lite（PL 侧引脚）
# ============================================================

# ===== 时钟：PL_CLK_50M @ N18，50MHz =====
create_clock -period 20.000 -name sys_clk [get_ports clk]
set_property PACKAGE_PIN N18 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]

# ===== UART（115200 8N1，PL 引脚 + 外接 USB-TTL）=====
# 板载 USB-UART 是 PS_MIO14/15（C5/C8），PL 用不了，改接扩展排针 GPIO2_0：
#   CPU tx  → GPIO2_0N L17 → USB-TTL 模块的 RX
#   CPU rx  ← GPIO2_0P L16 ← USB-TTL 模块的 TX
set_property PACKAGE_PIN L17 [get_ports tx]
set_property IOSTANDARD LVCMOS33 [get_ports tx]

set_property PACKAGE_PIN L16 [get_ports rx]
set_property IOSTANDARD LVCMOS33 [get_ports rx]

# ===== 复位：PL_KEY1 @ P16，按下低电平有效 =====
# top 端口 rst_n：平时上拉为高（不复位），按下拉低 → 复位
set_property PACKAGE_PIN P16 [get_ports rst_n]
set_property IOSTANDARD LVCMOS33 [get_ports rst_n]
