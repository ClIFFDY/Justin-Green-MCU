`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/14 06:32:02
// Design Name: 
// Module Name: irq_controller
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module irq_controller(
    input wire clk, rst, iret, 
    input wire [5:0] irq_addr_in,
    input wire [7:0] pc_addr_in, bytmov,
    output reg [7:0] irq_addr,
    output reg irq_flush
    );

    reg [7:0] irq_vex [0:15];
    reg [7:0] pc_addr;
    reg irq_busy;
    initial begin
        pc_addr = 8'b0;
        irq_vex[0] = 8'd232;
    end

    always @(posedge clk) begin
        irq_flush <= 1'b0;
        irq_addr <= 8'b0;
        if (rst) begin
            irq_busy <= 1'b0;
            irq_flush <= 1'b0;
            irq_addr <= 8'b0;
        end
        else if (!irq_busy) begin
            if (irq_addr_in != 11'b0 && bytmov == 8'b0) begin
                irq_busy <= 1'b1;
                irq_flush <= 1'b1;
                pc_addr <= pc_addr_in;
                irq_addr <= irq_vex[irq_addr_in[5:3] + irq_addr_in[2:0] - 1];
            end
        end
        else begin
            if (iret == 1'b1) begin 
                irq_busy <= 1'b0;
                irq_flush <= 1'b1;
                irq_addr <= pc_addr;
            end
        end
    end
endmodule
