`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/14 04:14:50
// Design Name: 
// Module Name: single_mcu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module single_mcu_top(
    input wire rst_n,
    input wire clk,
    output wire tx,
    input wire rx
    );

    reg rst_n_s1 = 1'b1;
    reg rst_n_s2 = 1'b1;
    always @(posedge clk) begin
        rst_n_s1 <= rst_n;
        rst_n_s2 <= rst_n_s1;
    end
    wire rst = ~rst_n_s2;

    wire [15:0] bus_addr_f;
    wire [7:0] bus_data_f;
    wire [3:0] bus_sig_f;
    reg [7:0] bus_data_b;
    wire tx_flg;
    wire stall_bus;

    wire [7:0] bus_data_uart;
    wire [7:0] bus_data_ram;

    reg [5:0] irq_bus;
    wire rx_irq;

    always @(*) begin
        case (bus_addr_f[15:13])
        3'b001: bus_data_b = bus_data_ram;
        3'b010: bus_data_b = bus_data_uart;
        default: bus_data_b = 8'b0;
        endcase
    end

    always @(*) begin
        irq_bus = 6'b0;
        if (rx_irq != 1'b0) irq_bus[5:3] = 3'b001;
    end

    single_cpu_top u_cpu(
        .clk(clk),
        .rst(rst),
        .bus_data_in(bus_data_b),
        .tx_busy(tx_busy),
        .stall_bus(stall_bus),
        .irq_bus(irq_bus),
        //
        .bus_addr_out(bus_addr_f),
        .bus_data_out(bus_data_f),
        .bus_sig_out(bus_sig_f)
    );

    uart_top u_uart(
        .clk(clk),
        .rst(rst),
        .rx(rx),
        .bus_addr_in(bus_addr_f),   
        .bus_data_in(bus_data_f),
        .bus_sig_in(bus_sig_f),
        //
        .rx_irq(rx_irq),
        .tx(tx),
        .bus_data_out(bus_data_uart),
        .tx_busy(tx_busy)
    );

    data_ram u_data_ram(
        .clk(clk),
        .bus_addr_in(bus_addr_f),
        .bus_data_in(bus_data_f),
        .bus_sig_in(bus_sig_f),
        //
        .bus_data_out(bus_data_ram),
        .stall_bus(stall_bus)
    );

endmodule
