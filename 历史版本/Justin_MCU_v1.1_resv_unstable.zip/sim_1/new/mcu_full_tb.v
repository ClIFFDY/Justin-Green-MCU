`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/14 04:17:27
// Design Name:
// Module Name: mcu_full_tb
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// MCU 整机测试（mcu_full_tb）：针对重构后的总线化架构
//   single_mcu_top = single_cpu_top + uart_top + data_ram（外设经总线挂载）
// 载入 cpu_full_test.hex（综合大程序），一次检查：
//   段1 算术/逻辑自检（r1..r11）→ 段2 调用返回（r12..r14）→ HALT
// 地址映射：data_ram=0x2000 段、uart=0x4000 段（hex 已对齐）。
// UART 收发验证走中断方案（uart_rx→IRQ→ISR），见 /e/tmp/irq_test_tb.v + irq_test.hex。
// 运行：cd project_self-try.srcs && /d/iverilog/bin/iverilog -g2012 -o mcu_sim \
//          sources_1/new/*.v sim_1/new/mcu_full_tb.v && /d/iverilog/bin/vvp mcu_sim
//////////////////////////////////////////////////////////////////////////////////

module mcu_full_tb;

    reg clk = 0, rst_n = 1, rx = 1;
    wire tx;

    single_mcu_top u_top(
        .clk(clk),
        .rst_n(rst_n),
        .rx(rx),
        .tx(tx)
    );

    always #10 clk = ~clk;   // 50MHz

    integer errors = 0;

    // ===== 载入指令（MCU 顶层下 u_cpu 内 ins_rom）=====
    initial begin
        $readmemh("E:/Vivado_Projects/project_self-try/project_self-try.srcs/cpu_full_test.hex", u_top.u_cpu.u_ins_rom.mem);
    end

    // ===== 复位 =====
    initial begin
        rst_n = 0;
        #20
        rst_n = 1;
    end

    // ===== 寄存器检查（层次引用 u_cpu.u_reg_f.regs）=====
    task checkr(input [7:0] idx, input [7:0] exp);
        begin
            if (u_top.u_cpu.u_reg_f.regs[idx] !== exp) begin
                $display("FAIL r%0d = 0x%02x (期望 0x%02x)", idx, u_top.u_cpu.u_reg_f.regs[idx], exp);
                errors = errors + 1;
            end
            else
                $display("OK   r%0d = 0x%02x", idx, u_top.u_cpu.u_reg_f.regs[idx]);
            end
    endtask

    // ===== 主流程 =====
    initial begin
        #8000;
        $display("---- 段1 算术/逻辑自检 ----");
        checkr(8'd1,  8'h41);
        checkr(8'd2,  8'h42);
        checkr(8'd3,  8'h3A);
        checkr(8'd4,  8'h0F);
        checkr(8'd5,  8'h0A);
        checkr(8'd6,  8'h3A);
        checkr(8'd7,  8'h22);
        checkr(8'd8,  8'h78);
        checkr(8'd9,  8'h1E);
        checkr(8'd10, 8'h01);
        checkr(8'd11, 8'h00);
        $display("---- 段2 调用返回 ----");
        checkr(8'd12, 8'h24);
        checkr(8'd13, 8'h27);
        checkr(8'd14, 8'hAA);

        if (errors == 0)
            $display("===== ALL TESTS PASSED =====");
        else
            $display("===== FAIL: %0d error(s) =====", errors);
        $finish;
    end

    // 兜底
    initial begin
        #600000;
        $display("===== TIMEOUT =====");
        $finish;
    end

endmodule
