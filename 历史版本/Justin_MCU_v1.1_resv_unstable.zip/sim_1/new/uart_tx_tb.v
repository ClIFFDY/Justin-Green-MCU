`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// uart_tx 独立测试：验证 1 起始 + 8 数据 + 1 停止 帧格式
//   - 每 bit 时长 MCNT 拍（115200 波特，50MHz → MCNT=434）
//   - 数据位 LSB-first
//   - 停止位必须为高（回归检查停止位 bug）
//   - busy 期间写入被屏蔽（不打断当前帧、结束后不连发）
// 运行：cd project_self-try.srcs && /d/iverilog/bin/iverilog -g2012 -o uart_tb_sim \
//          sources_1/new/uart_tx.v sim_1/new/uart_tx_tb.v && /d/iverilog/bin/vvp uart_tb_sim
//////////////////////////////////////////////////////////////////////////////////

module uart_tx_tb;

    reg  clk = 0;
    reg  rst = 1;
    reg  tx_en = 0;
    reg  [7:0] tx_data = 8'h00;
    wire tx, busy;

    localparam MCNT = 50000000 / 115200;   // 434

    integer errors = 0;
    reg [9:0] sampled = 10'b0;   // 采样到的 start + 8 数据 + stop

    uart_tx uut(
        .clk(clk),
        .rst(rst),
        .tx_en(tx_en),
        .tx_data(tx_data),
        .tx(tx),
        .busy(busy)
    );

    always #10 clk = ~clk;

    // 等待一次完整发送并逐 bit 中点采样校验
    task send_and_check;
        input [7:0] data;
        integer i;
        begin
            tx_data = data;
            tx_en = 1;
            @(posedge busy);            // 帧开始（busy 0→1，此刻 tx 已拉低）
            tx_en = 0;                  // 电平式触发，必须撤掉使能，否则帧后会连发

            // 起始位：中点应为 0
            repeat (MCNT/2) @(posedge clk);
            sampled[0] = tx;
            if (tx !== 1'b0) begin
                $display("FAIL @%0t 字节0x%02x: 起始位应=0 实际=%b", $time, data, tx);
                errors = errors + 1;
            end

            // 8 个数据位 LSB-first
            for (i = 0; i < 8; i = i + 1) begin
                repeat (MCNT) @(posedge clk);
                sampled[i+1] = tx;
                if (tx !== data[i]) begin
                    $display("FAIL @%0t 字节0x%02x: 数据位%d 应=%b 实际=%b", $time, data, i, data[i], tx);
                    errors = errors + 1;
                end
            end

            // 停止位：中点应为 1
            repeat (MCNT) @(posedge clk);
            sampled[9] = tx;
            if (tx !== 1'b1) begin
                $display("FAIL @%0t 字节0x%02x: 停止位应=1 实际=%b", $time, data, tx);
                errors = errors + 1;
            end

            @(negedge busy);            // 帧结束，busy 释放
            $display("PASS @%0t 字节0x%02x: 帧=[0%b1] %0d拍/bit 通过", $time, data, sampled, MCNT);
        end
    endtask

    // busy 期间给 tx_en 应被屏蔽（不打断当前帧、结束后不连发）
    task drop_write_test;
        begin
            tx_data = 8'h55;
            tx_en = 1;
            @(posedge busy);
            tx_en = 0;

            // 帧中途（第 3~4 数据位之间）脉冲一次 tx_en
            repeat (MCNT * 3 + 100) @(posedge clk);
            tx_en = 1;
            @(posedge clk);
            tx_en = 0;

            if (busy !== 1'b1) begin
                $display("FAIL @%0t: busy 期间写入未屏蔽（busy 不应变低）", $time);
                errors = errors + 1;
            end

            @(negedge busy);            // 原帧自然结束
            repeat (10) @(posedge clk);
            if (busy !== 1'b0 || tx !== 1'b1) begin
                $display("FAIL @%0t: 被屏蔽的写入不应产生新帧（busy=%b tx=%b）", $time, busy, tx);
                errors = errors + 1;
            end
            $display("PASS @%0t: busy 期间写入被屏蔽，无额外帧", $time);
        end
    endtask

    // 兜底超时，防卡死
    initial begin
        #1000000
        $display("TIMEOUT: 仿真卡住");
        errors = errors + 1;
        $finish;
    end

    initial begin
        $dumpfile("uart_tx_tb.vcd");
        $dumpvars(0, uart_tx_tb);

        repeat (5) @(posedge clk);
        rst = 0;
        @(posedge clk);

        send_and_check(8'hA5);   // 交替 1/0，最能查移位/串序
        send_and_check(8'h01);   // 数据位几乎全 0，最能查停止位
        send_and_check(8'hFF);   // 全 1
        drop_write_test();

        if (errors == 0)
            $display("===== ALL TESTS PASSED =====");
        else
            $display("===== %0d ERRORS =====", errors);
        $finish;
    end

endmodule
