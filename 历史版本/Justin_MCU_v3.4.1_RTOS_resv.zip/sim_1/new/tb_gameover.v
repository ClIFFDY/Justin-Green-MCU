`timescale 1ns / 1ps
module tb_gameover;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus));
    always #10 clk = ~clk;

    initial begin
        repeat(3000) @(posedge clk);   // 测试程序很短，几千拍足够
        $display("=== TEST1(row0占满,块在row0): r1=%02X (期望 01=blocked) ===",
            u_top.u_ram_top.ram_sec_2.mem[16'h500]);
        $display("=== TEST2(cell在row-1): r1=%02X (期望 01=blocked, bug下=00=free) ===",
            u_top.u_ram_top.ram_sec_2.mem[16'h501]);
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
    end
    initial begin
        #1;
        $readmemh("test_gameover.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
