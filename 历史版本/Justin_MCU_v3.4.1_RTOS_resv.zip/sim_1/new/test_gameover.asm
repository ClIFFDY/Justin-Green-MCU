# ============================================================
# 聚焦测试：俄罗斯方块"堆到顶→失败判定"
#   check_candidate + check_cell（从固件抽出）
#   用例1：场地 row0 全占 → 新块 cells 在 row0 → 应判 blocked(1)
#   用例2：cell 在 row-1(0xFF) → 应判 blocked(1)，但代码判 free(0) ← bug
#   结果写 0x9500（用例1）0x9501（用例2）
# ============================================================
.equ FIELD_BASE 0x9400
.equ C_ROW1 0x943C
.equ C_COL1 0x943D
.equ C_ROW2 0x943E
.equ C_COL2 0x943F
.equ C_ROW3 0x9440
.equ C_COL3 0x9441
.equ C_ROW4 0x9442
.equ C_COL4 0x9443
.equ TEST1 0x9500
.equ TEST2 0x9501

.org 0x000
    ADDI  r253, r0, 0        # j=0（调用栈基址）
    SBI   0x00, 0xD000       # baseline=0

    # ================= 用例1：row0 全占，块在 row0 → blocked ================
    # 场地 row0 占满（mask 0x3FF: lo=0xFF hi=0x03）
    ADDI  r1, r0, 0xFF
    SB    r1, FIELD_BASE
    ADDI  r1, r0, 0x03
    SB    r1, FIELD_BASE+1
    # 候选块 4 cells 都在 row0：cols 3,4,5,6
    ADDI  r1, r0, 0
    SB    r1, C_ROW1
    ADDI  r1, r0, 3
    SB    r1, C_COL1
    ADDI  r1, r0, 0
    SB    r1, C_ROW2
    ADDI  r1, r0, 4
    SB    r1, C_COL2
    ADDI  r1, r0, 0
    SB    r1, C_ROW3
    ADDI  r1, r0, 5
    SB    r1, C_COL3
    ADDI  r1, r0, 0
    SB    r1, C_ROW4
    ADDI  r1, r0, 6
    SB    r1, C_COL4
    RJAL  check_candidate      # r1 = 1 (blocked → 失败)
    SB    r1, TEST1

    # ================= 用例2：cell 在 row-1(0xFF) → 应 blocked ================
    # 清场地 row0（让 row0 空）
    SB    r0, FIELD_BASE
    SB    r0, FIELD_BASE+1
    # 候选块 cell1 在 row-1(0xFF)，其余 row0
    ADDI  r1, r0, 0xFF
    SB    r1, C_ROW1
    ADDI  r1, r0, 3
    SB    r1, C_COL1
    ADDI  r1, r0, 0
    SB    r1, C_ROW2
    ADDI  r1, r0, 4
    SB    r1, C_COL2
    ADDI  r1, r0, 0
    SB    r1, C_ROW3
    ADDI  r1, r0, 5
    SB    r1, C_COL3
    ADDI  r1, r0, 0
    SB    r1, C_ROW4
    ADDI  r1, r0, 6
    SB    r1, C_COL4
    RJAL  check_candidate      # 应=1(blocked)，bug 下=0(free)
    SB    r1, TEST2

    HALT

# ---- check_candidate（从固件抽出）：r1 = 0 free / 1 blocked ----
check_candidate:
    ADDI  r1, r0, 0x94
    ADDI  r2, r0, 0x3C
    ADDI  r12, r0, 4
__cc_loop:
    LIND  r3, r1, r2
    ADDI  r2, r2, 1
    LIND  r4, r1, r2
    ADDI  r2, r2, 1
    RJAL  check_cell
    RBNE  r5, r0, __cc_blocked
    ADDI  r12, r12, 0xFF
    RBNE  r12, r0, __cc_loop
    ADDI  r1, r0, 0
    JALR
__cc_blocked:
    ADDI  r1, r0, 1
    JALR

# ---- check_cell（从固件抽出）：r3=row r4=col -> r5=0 free / 1 blocked ----
check_cell:
    ADDI  r6, r0, 0x80
    RBLTU r6, r3, __ce_blocked
    ADDI  r6, r0, 20
    RBLTU r3, r6, __ce_rowok
    RBEQ  r0, r0, __ce_blocked
__ce_rowok:
    ADDI  r6, r0, 0x80
    RBLTU r6, r4, __ce_blocked
    ADDI  r6, r0, 9
    RBLTU r6, r4, __ce_blocked
    SLLI  r11, r3, 1
    ADDI  r10, r0, 0x94
    ADDI  r5, r11, 0
    LIND  r6, r10, r11
    ADDI  r11, r5, 1
    LIND  r7, r10, r11
    ADDI  r8, r4, 0
    ADDI  r9, r0, 8
    RBLTU r8, r9, __ce_lobit
    ADDI  r8, r8, 0xF8
    ADDI  r6, r7, 0
    RBEQ  r0, r0, __ce_bt
__ce_lobit:
__ce_bt:
    RBNE  r8, r0, __ce_shift
    RBEQ  r0, r0, __ce_test
__ce_shift:
    SRLI  r6, r6, 1
    ADDI  r8, r8, 0xFF
    RBEQ  r0, r0, __ce_bt
__ce_test:
    ANDI  r6, r6, 1
    RBNE  r6, r0, __ce_blocked
__ce_free:
    ADDI  r5, r0, 0
    JALR
__ce_blocked:
    ADDI  r5, r0, 1
    JALR
