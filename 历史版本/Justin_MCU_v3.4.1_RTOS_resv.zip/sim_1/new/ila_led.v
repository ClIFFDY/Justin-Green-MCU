`timescale 1ns / 1ps
// ILA 仿真 stub：Vivado 综合时用真实 IP，iverilog 仿真用这个空壳
module ila_led(
    input wire clk,
    input wire [119:0] probe0
);
endmodule
