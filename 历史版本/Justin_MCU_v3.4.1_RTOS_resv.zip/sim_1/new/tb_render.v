`timescale 1ns / 1ps
module tb_render;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus));
    always #10 clk = ~clk;

    // pc trace every 5 cycles (only around the render, after cycle 800)
    integer pcnt = 0;
    always @(posedge clk) begin
        pcnt = pcnt + 1;
        if (pcnt > 800 && pcnt < 2600 && (pcnt % 40 == 0)) $display("PC %03X", u_top.u_cpu.u_pc.pc_addr);
    end

    initial begin
        repeat(30000) @(posedge clk);   // render 写完帧 + DMA
        $display("=== pc=%03X FRAME_IDX=%02X%02X field0=%02X%02X bank=0x%02X ===",
            u_top.u_cpu.u_pc.pc_addr,
            u_top.u_ram_top.ram_sec_2.mem[16'h48B], u_top.u_ram_top.ram_sec_2.mem[16'h48C],
            u_top.u_ram_top.ram_sec_2.mem[16'h400], u_top.u_ram_top.ram_sec_2.mem[16'h401],
            u_top.u_ram_ext_top.bank_num);
        $display("=== 帧缓冲 0xC000 前 320 字节 ===");
        for (integer i = 0; i < 320; i = i + 1) begin
            if (i % 32 == 0) $write("\n%04X: ", 16'hC000 + i);
            $write("%c", u_top.u_ram_ext_top.ram_ext_1.mem[i]);
        end
        $display("");
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
    end
    initial begin
        #1;
        $readmemh("test_render.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
