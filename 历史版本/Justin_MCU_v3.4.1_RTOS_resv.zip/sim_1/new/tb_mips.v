`timescale 1ns / 1ps
module tb_mips;
    reg clk = 0, rst_n = 1;
    wire [7:0] gpio_pin_bus;
    assign gpio_pin_bus = 8'bz;
    pullup (gpio_pin_bus[0]); pullup (gpio_pin_bus[1]);
    single_mcu_top u_top(.clk(clk), .rst_n(rst_n), .gpio_pin_bus(gpio_pin_bus));
    always #10 clk = ~clk;

    // division loop iteration counter (pc 0x627-0x637)
    integer div_cnt = 0;
    integer cyc = 0;
    always @(posedge clk) begin
        cyc = cyc + 1;
        if (u_top.u_cpu.u_pc.pc_addr >= 13'h627 && u_top.u_cpu.u_pc.pc_addr <= 13'h637)
            div_cnt = div_cnt + 1;
    end

    // E 读窗口总线探针：每周期 bus_addr_out + timer 数据 + 返回数据
    always @(posedge clk) begin
        if (cyc > 5773400 && cyc < 5773800)
            $display("BUS %0d addr=%04X sig=%b timer_out=%02X cpu_in=%02X pc=%03X",
                cyc, u_top.u_cpu.u_decoder.bus_addr_out, u_top.u_cpu.u_decoder.bus_sig_out,
                u_top.u_timer.bus_data_out, u_top.bus_data_b, u_top.u_cpu.u_pc.pc_addr);
    end

    // timer 读探针：CPU LBU TIMER_CNT0(0x3000) 时 dump timer 计数
    integer tn = 0;
    always @(posedge clk) begin
        if (cyc > 3000000 && tn < 12 &&
            u_top.u_cpu.u_decoder.bus_addr_out == 16'h3000 &&
            u_top.u_cpu.u_decoder.bus_sig_out == 4'b0000) begin
            tn = tn + 1;
            $display("TIM %0d pc=%03X timer_cnt=%02X%02X%02X%02X",
                cyc, u_top.u_cpu.u_pc.pc_addr,
                u_top.u_timer.cnt[3], u_top.u_timer.cnt[2], u_top.u_timer.cnt[1], u_top.u_timer.cnt[0]);
        end
    end

    // MIPS 基准探针：S/E 存储时刻 timer 计数 + 存的值
    integer n_s = 0, n_e = 0;
    always @(posedge clk) begin
        if (u_top.u_ram_top.bus_sig_in[0] && u_top.u_ram_top.bus_addr_in == 16'h9128 && n_s < 4) begin
            $display("S%0d @%0d cpu_store=%02X timer_cnt=%02X%02X%02X%02X pc=%03X",
                n_s, cyc, u_top.u_ram_top.bus_data_in,
                u_top.u_timer.cnt[3], u_top.u_timer.cnt[2], u_top.u_timer.cnt[1], u_top.u_timer.cnt[0],
                u_top.u_cpu.u_pc.pc_addr);
            n_s = n_s + 1;
        end
        if (u_top.u_ram_top.bus_sig_in[0] && u_top.u_ram_top.bus_addr_in == 16'h912C && n_e < 4) begin
            $display("E%0d @%0d cpu_store=%02X timer_cnt=%02X%02X%02X%02X pc=%03X",
                n_e, cyc, u_top.u_ram_top.bus_data_in,
                u_top.u_timer.cnt[3], u_top.u_timer.cnt[2], u_top.u_timer.cnt[1], u_top.u_timer.cnt[0],
                u_top.u_cpu.u_pc.pc_addr);
            n_e = n_e + 1;
        end
    end

    // UART output capture
    integer txc = 0;
    reg [7:0] txbuf [0:2047];
    always @(posedge clk) begin
        if (u_top.u_cpu.u_decoder.bus_sig_out[0] && u_top.u_cpu.u_decoder.bus_addr_out[15:12] == 4'h2) begin
            if (txc < 2048) txbuf[txc] = u_top.u_cpu.u_decoder.bus_data_out;
            txc = txc + 1;
        end
    end

    // send a UART byte on rx (MCNT=2, bit=2 cycles). Align to negedge, then drive.
    task uart_send;
        input [7:0] b;
        integer k;
        begin
            @(negedge clk);
            force u_top.rx = 1'b1;   // idle
            #40;
            force u_top.rx = 1'b0;   // start
            #40;
            for (k = 0; k < 8; k = k + 1) begin
                force u_top.rx = b[k];
                #40;
            end
            force u_top.rx = 1'b1;   // stop
            #40;
            release u_top.rx;
            #60;
        end
    endtask

    initial begin
        repeat(3300000) @(posedge clk);   // ~66ms: boot + menu (typewriter slow)
        $display("=== send '2' (t=%0t) ===", $time);
        uart_send(8'h32);
        repeat(20000) @(posedge clk);     // ~0.4ms (echo)
        $display("=== send CR ===");
        uart_send(8'h0D);
        repeat(5000000) @(posedge clk);   // OUTER=5 Dhrystone (~4M 周期)
        $display("=== q(reg20)=%02X reg1=%02X reg3=%02X reg5=%02X ===",
            u_top.u_cpu.u_reg_f.regs[20], u_top.u_cpu.u_reg_f.regs[1],
            u_top.u_cpu.u_reg_f.regs[3], u_top.u_cpu.u_reg_f.regs[5]);
        $display("=== MIPS_S=%02X%02X%02X%02X MIPS_E=%02X%02X%02X%02X MIPS_N=%02X%02X ===",
            u_top.u_ram_top.ram_sec_2.mem[16'h128], u_top.u_ram_top.ram_sec_2.mem[16'h129],
            u_top.u_ram_top.ram_sec_2.mem[16'h12A], u_top.u_ram_top.ram_sec_2.mem[16'h12B],
            u_top.u_ram_top.ram_sec_2.mem[16'h12C], u_top.u_ram_top.ram_sec_2.mem[16'h12D],
            u_top.u_ram_top.ram_sec_2.mem[16'h12E], u_top.u_ram_top.ram_sec_2.mem[16'h12F],
            u_top.u_ram_top.ram_sec_2.mem[16'h130], u_top.u_ram_top.ram_sec_2.mem[16'h131]);
        $display("=== timer cnt=%02X%02X%02X%02X ===",
            u_top.u_timer.cnt[0], u_top.u_timer.cnt[1], u_top.u_timer.cnt[2], u_top.u_timer.cnt[3]);
        $display("=== txc=%0d ===", txc);
        for (integer i = 0; i < txc && i < 2048; i = i + 1) $write("%c", (txbuf[i] >= 32 && txbuf[i] < 127) ? txbuf[i] : ".");
        $display("");
        $finish;
    end
    initial begin
        rst_n = 0; #100; rst_n = 1;
        repeat(15) @(posedge clk);
        force u_top.u_rst_buf.rst_stable = 1'b0;
    end
    initial begin
        #1;
        $readmemh("ins_rom.hex", u_top.u_cpu.u_ins_rom.mem);
    end
endmodule
