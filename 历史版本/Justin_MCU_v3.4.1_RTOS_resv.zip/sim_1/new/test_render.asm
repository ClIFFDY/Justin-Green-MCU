# 聚焦测试：堆满场地 → render → dump 帧缓冲(0xC000)
.equ FIELD_BASE 0x9400
.equ FRAME_IDX_LO 0x948B
.equ FRAME_IDX_HI 0x948C
.equ P_ROW1 0x9430
.equ P_COL1 0x9431
.equ P_ROW2 0x9432
.equ P_COL2 0x9433
.equ P_ROW3 0x9434
.equ P_COL3 0x9435
.equ P_ROW4 0x9436
.equ P_COL4 0x9437
.equ G_SCORE 0x9480
.equ G_LAST_TICK 0x9481
.equ TICK_LO    0x9000
.equ DMA_INI    0x70C0
.equ DMA_CNT    0x7100
.equ DMA_DES    0x7320
.equ DMA_BANK   0x7400
.equ DMA_TRIG   0x7500
.equ DMA_CNT_HI 0x7600
.equ DMA_CNT_LO 0x7700

.org 0x000
    ADDI  r253, r0, 0        # j=0
    SBI   0x00, 0xD000       # baseline=0
    # 选片 ram_ext bank0（帧缓冲 0xC000）
    SB    r0, 0xB000
    # 堆满场地 row0-5（写 12 字节 0xFF，mask 全 1）
    ADDI  r1, r0, 0x94       # addr hi
    ADDI  r2, r0, 0x00       # addr lo
    ADDI  r5, r0, 0xFF       # data
    ADDI  r6, r0, 12         # 12 bytes
__fl:
    SIND  r5, r1, r2         # 写 {0x94, lo}
    ADDI  r2, r2, 1
    ADDI  r6, r6, 0xFF
    RBNE  r6, r0, __fl
    # 清当前块 + 分数
    SB    r0, P_ROW1
    SB    r0, P_COL1
    SB    r0, P_ROW2
    SB    r0, P_COL2
    SB    r0, P_ROW3
    SB    r0, P_COL3
    SB    r0, P_ROW4
    SB    r0, P_COL4
    SB    r0, G_SCORE
    # 调 render（build 帧到 0xC000 + DMA 发送）
    RJAL  render
    HALT

set_bit:                   # r1=lo r2=hi r4=col -> r1|bit / r2|bit
    ADDI  r5, r0, 1
    ADDI  r6, r4, 0
__sb_loop:
    RBNE  r6, r0, __sb_shift
    RBEQ  r0, r0, __sb_or
__sb_shift:
    SLLI  r5, r5, 1
    ADDI  r6, r6, 0xFF
    RBEQ  r0, r0, __sb_loop
__sb_or:
    ADDI  r6, r0, 8
    RBLTU r4, r6, __sb_lo
    # col 8/9：r5 已溢出（1<<8 在 8 位寄存器=0），特判 hi 位
    ADDI  r6, r0, 8
    RBEQ  r4, r6, __sb_hi1
    ADDI  r5, r0, 2
    OR    r2, r2, r5
    JALR
__sb_hi1:
    ADDI  r5, r0, 1
    OR    r2, r2, r5
    JALR
__sb_lo:
    OR    r1, r1, r5
    JALR

set_cell:                  # r3=row r4=col r13=基址低8位(0x00/0x50) -> 掩码|=1<<col
    ADDI  r6, r0, 0x80
    RBLTU r6, r4, __sc_out
    ADDI  r6, r0, 9
    RBLTU r6, r4, __sc_out
    ADDI  r6, r0, 0x80
    RBLTU r6, r3, __sc_out
    ADDI  r6, r0, 20
    RBLTU r3, r6, __sc_rowo
    RBEQ  r0, r0, __sc_out
__sc_rowo:
    SLLI  r2, r3, 1
    ADD   r2, r2, r13         # addr_lo = 基址低 + row*2
    ADDI  r1, r0, 0x94
    ADDI  r5, r2, 0
    LIND  r6, r1, r2          # lo
    ADDI  r2, r5, 1
    LIND  r7, r1, r2          # hi
    ADDI  r1, r6, 0
    ADDI  r2, r7, 0
    RJAL  set_bit
    ADDI  r8, r1, 0
    ADDI  r9, r2, 0
    SLLI  r2, r3, 1
    ADD   r2, r2, r13
    ADDI  r1, r0, 0x94
    SIND  r8, r1, r2          # 写回 lo'
    ADDI  r2, r2, 1
    SIND  r9, r1, r2          # 写回 hi'
__sc_out:
    JALR

apply_candidate:
    ADDI  r1, r0, 0x94
    ADDI  r2, r0, 0x3C
    ADDI  r5, r0, 0x30
    ADDI  r6, r0, 8
__ac_loop:
    LIND  r3, r1, r2
    SIND  r3, r1, r5
    ADDI  r2, r2, 1
    ADDI  r5, r5, 1
    ADDI  r6, r6, 0xFF
    RBNE  r6, r0, __ac_loop

fputc:                       # 入参 r7=字符；写 FRAME_BUF+FRAME_IDX(16bit)
    # 调度器 GAME 模式保存 r12-r14（GAME_S1-3），r15 会被调度器覆盖，勿用
    LBU   r13, FRAME_IDX_LO
    LBU   r14, FRAME_IDX_HI
    ADDI  r14, r14, 0xC0     # 高字节 = 0xC0 + HI（帧 >255 时地址到 0xC100）
    SIND  r7, r14, r13
    ADDI  r13, r13, 1        # 16 位自增（LO 回绕时进位 HI）
    ANDI  r12, r13, 0xFF
    SB    r13, FRAME_IDX_LO
    RBNE  r12, r0, __fputc_done
    LBU   r12, FRAME_IDX_HI
    ADDI  r12, r12, 1
    SB    r12, FRAME_IDX_HI
__fputc_done:
    JALR

fput_crlf:
    ADDI  r7, r0, '\r'
    RJAL  fputc
    ADDI  r7, r0, '\n'
    RJAL  fputc
    JALR

fprint_hex:                   # 入参 r7=字节 → 2 位 hex（帧版；r10 备份原字节，fprint_hexdigit 破坏 r7/r8/r9）
    ADDI  r8, r7, 0
    ADDI  r10, r7, 0
    SRLI  r8, r8, 4
    ANDI  r8, r8, 0xF
    RJAL  fprint_hexdigit
    ANDI  r8, r10, 0xF
    RJAL  fprint_hexdigit
    JALR

fprint_hexdigit:              # 入参 r8=0-15 → 1 个 hex 字符（帧版）
    ADDI  r9, r8, 0
    ADDI  r8, r0, 10
    RBLTU r9, r8, __fhd_num
    ADDI  r7, r9, 0x37
    RJAL  fputc
    JALR
__fhd_num:
    ADDI  r7, r9, '0'
    RJAL  fputc
    JALR

wait_dma:                     # 等 DMA 完成（cnt==0；首帧 cnt=0 直接过）
    LBU   r1, DMA_CNT_HI
    RBNE  r1, r0, wait_dma
    LBU   r1, DMA_CNT_LO
    RBNE  r1, r0, wait_dma
    JALR

dma_frame_send:               # 配置 DMA：ini=0xC000(bank0) → des=UART + 触发
    SB    r0, DMA_INI
    LBU   r1, FRAME_IDX_LO
    LBU   r2, FRAME_IDX_HI
    ADDI  r3, r0, 0x71         # cnt 寄存器基址 0x7100（地址字节=高字节）
    SIND  r1, r3, r2           # cnt={地址[7:0]=HI, 数据=LO} → 16 位帧长（319=0x13F）
    SB    r0, DMA_DES
    SB    r0, DMA_BANK
    SB    r0, DMA_TRIG
    JALR

render:
    SB    r0, FRAME_IDX_LO      # 帧指针清零（16bit）
    SB    r0, FRAME_IDX_HI
    RJAL  wait_dma               # 等上一帧 DMA 完成（首帧 cnt=0 直接过）
    # 清 render_mask（SIND 循环 40 字节）
    ADDI  r1, r0, 0x94
    ADDI  r2, r0, 0x50
    ADDI  r3, r0, 40
__clr_ren:
    SIND  r0, r1, r2
    ADDI  r2, r2, 1
    ADDI  r3, r3, 0xFF
    RBNE  r3, r0, __clr_ren
    # 叠方块 4 格（render_cell = set_cell + 基址 0x50）
    ADDI  r13, r0, 0x50
    LBU   r3, P_ROW1
    LBU   r4, P_COL1
    RJAL  set_cell
    LBU   r3, P_ROW2
    LBU   r4, P_COL2
    RJAL  set_cell
    LBU   r3, P_ROW3
    LBU   r4, P_COL3
    RJAL  set_cell
    LBU   r3, P_ROW4
    LBU   r4, P_COL4
    RJAL  set_cell
    # 顶边框（帧缓冲）
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    RJAL  fput_crlf
    # 20 行循环
    ADDI  r17, r0, 0            # r17 = 行
__r_loop:
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r3, r17, 0
    SLLI  r2, r3, 1
    ADDI  r1, r0, 0x94
    ADDI  r5, r2, 0
    LIND  r6, r1, r2           # field lo
    ADDI  r2, r5, 1
    LIND  r7, r1, r2           # field hi
    ADDI  r2, r5, 0x50         # render lo 地址
    LIND  r4, r1, r2
    ADDI  r2, r5, 0x51         # render hi 地址
    LIND  r8, r1, r2
    OR    r6, r6, r4
    OR    r7, r7, r8
    ADDI  r1, r6, 0
    ADDI  r2, r7, 0
    RJAL  print_cells
    ADDI  r7, r0, '@'
    RJAL  fputc
    RJAL  fput_crlf
    ADDI  r17, r17, 1
    ADDI  r1, r17, 0
    ADDI  r2, r0, 20
    RBLTU r1, r2, __r_loop
    # 底边框（帧缓冲）
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    ADDI  r7, r0, '@'
    RJAL  fputc
    RJAL  fput_crlf
    # SCORE 行（帧版）
    ADDI  r7, r0, 'S'
    RJAL  fputc
    ADDI  r7, r0, 'C'
    RJAL  fputc
    ADDI  r7, r0, 'O'
    RJAL  fputc
    ADDI  r7, r0, 'R'
    RJAL  fputc
    ADDI  r7, r0, 'E'
    RJAL  fputc
    ADDI  r7, r0, ':'
    RJAL  fputc
    ADDI  r7, r0, ' '
    RJAL  fputc
    LBU   r7, G_SCORE
    RJAL  fprint_hex
    RJAL  fput_crlf
    # 诊断：render 完成标记
    ADDI  r1, r0, 0x55
    SB    r1, 0x948D
    # 发送 DMA（帧缓冲 0xC000 → UART）
    RJAL  dma_frame_send
    JALR

print_cells:               # r1=lo(8格) r2=hi(2格) -> 打印 10 格（帧版，fputc）
    ADDI  r6, r0, 8
__pc_loop:
    ANDI  r3, r1, 1
    RBNE  r3, r0, __pc_hash
    ADDI  r7, r0, '.'
    RJAL  fputc
    RBEQ  r0, r0, __pc_next
__pc_hash:
    ADDI  r7, r0, '#'
    RJAL  fputc
__pc_next:
    SRLI  r1, r1, 1
    ADDI  r6, r6, 0xFF
    RBNE  r6, r0, __pc_loop
    # hi 2 格（col 8/9）
    ADDI  r6, r0, 2
__pc_hi:
    ANDI  r3, r2, 1
    RBNE  r3, r0, __pc_hhash
    ADDI  r7, r0, '.'
    RJAL  fputc
    RBEQ  r0, r0, __pc_hnext
__pc_hhash:
    ADDI  r7, r0, '#'
    RJAL  fputc
__pc_hnext:
    SRLI  r2, r2, 1
    ADDI  r6, r6, 0xFF
    RBNE  r6, r0, __pc_hi
    JALR

drop_check:
    LBU   r1, TICK_LO
    LBU   r2, G_LAST_TICK