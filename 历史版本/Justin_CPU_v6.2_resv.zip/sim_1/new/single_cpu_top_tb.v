`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/10 00:36:53
// Design Name:
// Module Name: single_cpu_top_tb
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module single_cpu_top_tb();

    reg clk, rst;
    integer fd;   // 日志文件句柄

    single_cpu_top u_single_cpu_top(
        .clk(clk),
        .rst(rst)
    );

    // 时钟：周期 10ns
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // 复位：前 20ns 拉高后放开（单次运行，输出干净；要测试重启再加第二次脉冲）
    initial begin
        rst = 1;
        #20
        rst = 0;
    end

    // 从 hex 文件载入指令到 ins_rom（层次引用；绝对路径，iverilog / Vivado 都能找到）
    initial begin
        $readmemh("E:/Vivado_Projects/project_self-try/project_self-try.srcs/ins_rom.hex", u_single_cpu_top.u_ins_rom.mem);
    end

    // 打开日志文件（相对 vvp 运行目录；每次运行都新建覆盖）
    initial fd = $fopen("cpu_alu_sim.log", "w");

    // ===== 每周期一行进日志：时间 | stage | pc | opcode =====
    // opcode 是 EX 级（id_reg 输出）那条指令；寄存器写事件记在同一拍后面
    reg done = 0;   // HALT 冻结（stage 掉 0）后置位，停止打印并收尾
    always @(posedge clk) begin
        if (!rst && !done) begin
            // 有寄存器写（提交）就追加在当拍行尾，不单独提行
            if (u_single_cpu_top.we && u_single_cpu_top.rd != 8'b0)
                $fdisplay(fd, "T=%4dns | stage=%b | pc=%2d | op=%b  r%0d = %0d",
                          $time, u_single_cpu_top.stage, u_single_cpu_top.pc_addr, u_single_cpu_top.opcode,
                          u_single_cpu_top.rd, u_single_cpu_top.rd_data);
            else
                $fdisplay(fd, "T=%4dns | stage=%b | pc=%2d | op=%b",
                          $time, u_single_cpu_top.stage, u_single_cpu_top.pc_addr, u_single_cpu_top.opcode);
        end
        // stdout：寄存器写事件单独一行（快速看结果用）
        if (!done && u_single_cpu_top.we && u_single_cpu_top.rd != 8'b0)
            $display("T=%4dns r%0d = %0d", $time, u_single_cpu_top.rd, u_single_cpu_top.rd_data);
    end

`ifdef DEBUG_TRACE
    // 每周期流水线各级 + 寄存器（stdout，调试用，编译加 -D DEBUG_TRACE）
    always @(posedge clk) begin
        $display("T=%4dns | stage=%b pc=%2d len=%d | dec(op=%b a1=%d a2=%d rd=%d) | ir(op=%b a1=%d a2=%d w=%d ralt=%b rl=%d imm=%d) | rs1=%d rs2=%d alu=%d | j=%d ra=%d jf=%b | r0=%d r1=%d r2=%d r3=%d r4=%d r5=%d r6=%d r7=%d r8=%d r9=%d r10=%d r11=%d r12=%d r13=%d r14=%d r15=%d r16=%d r17=%d r18=%d r19=%d r20=%d r21=%d r22=%d r23=%d r24=%d r25=%d r26=%d",
                 $time,
                 u_single_cpu_top.stage, u_single_cpu_top.pc_addr, u_single_cpu_top.inst_num,
                 u_single_cpu_top.op_temp, u_single_cpu_top.rd12[15:8], u_single_cpu_top.rd12[7:0], u_single_cpu_top.rd12[23:16],
                 u_single_cpu_top.opcode, u_single_cpu_top.r12[15:8], u_single_cpu_top.r12[7:0], u_single_cpu_top.rd_temp,
                 u_single_cpu_top.rs_alt2, u_single_cpu_top.result_last2, u_single_cpu_top.imm8,
                 u_single_cpu_top.r12_data[15:8], u_single_cpu_top.r12_data[7:0], u_single_cpu_top.result,
                 u_single_cpu_top.u_reg_f.j, u_single_cpu_top.u_reg_f.ra, u_single_cpu_top.u_reg_f.j_flag,
                 u_single_cpu_top.u_reg_f.regs[0], u_single_cpu_top.u_reg_f.regs[1],
                 u_single_cpu_top.u_reg_f.regs[2], u_single_cpu_top.u_reg_f.regs[3],
                 u_single_cpu_top.u_reg_f.regs[4], u_single_cpu_top.u_reg_f.regs[5],
                 u_single_cpu_top.u_reg_f.regs[6], u_single_cpu_top.u_reg_f.regs[7],
                 u_single_cpu_top.u_reg_f.regs[8], u_single_cpu_top.u_reg_f.regs[9],
                 u_single_cpu_top.u_reg_f.regs[10], u_single_cpu_top.u_reg_f.regs[11],
                 u_single_cpu_top.u_reg_f.regs[12], u_single_cpu_top.u_reg_f.regs[13],
                 u_single_cpu_top.u_reg_f.regs[14], u_single_cpu_top.u_reg_f.regs[15],
                 u_single_cpu_top.u_reg_f.regs[16], u_single_cpu_top.u_reg_f.regs[17],
                 u_single_cpu_top.u_reg_f.regs[18], u_single_cpu_top.u_reg_f.regs[19],
                 u_single_cpu_top.u_reg_f.regs[20], u_single_cpu_top.u_reg_f.regs[21],
                 u_single_cpu_top.u_reg_f.regs[22], u_single_cpu_top.u_reg_f.regs[23],
                 u_single_cpu_top.u_reg_f.regs[24], u_single_cpu_top.u_reg_f.regs[25],
                 u_single_cpu_top.u_reg_f.regs[26]);
    end
`endif

    integer halt_cnt = 0;   // 累计 HALT 冻结次数（= 程序跑完的遍数）
    // 第一次 HALT（stage 掉 0）→ 停机复位：拉高复位 ~25ns 重跑一遍。
    // reg_f 无复位端口，寄存器数据保留，自增的 r4 会翻倍，正好验证复位重启生效。
    // 第二次 HALT → 收尾。省掉 HALT 之后 pc 溜到 x 的噪声（写已全部提交）。
    always @(posedge clk) begin
        if (!rst && !done && u_single_cpu_top.stage == 1'b0) begin
            halt_cnt = halt_cnt + 1;
            if (halt_cnt == 1) begin
                rst = 1;
                #25
                rst = 0;
            end
            else begin
                done <= 1'b1;
                #15
                $fclose(fd);
                $finish(0);
            end
        end
    end

    // 兜底：万一程序没 HALT 永不结束，最多跑到 30us 强制收尾
    //（栈保护测试每遍要压栈到 j=255 满栈 + 深弹栈到空，各约 5us；
    //  第二遍复位后跑完约 21us，20us 不够，会截断第二遍弹栈循环）
    initial begin
        #30000
        $fclose(fd);
        $finish(0);
    end

endmodule
