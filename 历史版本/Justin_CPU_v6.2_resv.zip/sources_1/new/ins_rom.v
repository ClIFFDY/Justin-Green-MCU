`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 2026/08/09 22:05:38
// Design Name:
// Module Name: ins_rom
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module ins_rom(
    input wire [7:0] addr,
    output wire [31:0] inst_raw,
    output wire [1:0] inst_num
    );

    // 指令由 tb 通过 $readmemh("ins_rom.hex") 层次引用载入，本模块不再内嵌程序
    reg [7:0] mem [0:255];

    assign inst_num = mem[addr][1:0];
    assign inst_raw = {mem[addr], mem[addr + 1], mem[addr + 2], mem[addr + 3]};

endmodule
