`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/12 00:06:14
// Design Name: 
// Module Name: if_reg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module if_reg(
    input wire clk, flush_raw, stage, rst,
    input wire [31:0] inst_raw_in,
    output reg [31:0] inst_raw
    );

    localparam NOP = 6'b01_0100;

    always @(posedge clk) begin
        if (rst) inst_raw <= {NOP, 26'b0};
        else if (stage == 1'b1 && !flush_raw) begin
            inst_raw <= inst_raw_in;
        end
        else begin
            inst_raw <= {NOP, 26'b0};
        end
    end
endmodule
