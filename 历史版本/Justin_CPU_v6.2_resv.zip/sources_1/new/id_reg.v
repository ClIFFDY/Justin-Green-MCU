`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/12 00:18:11
// Design Name: 
// Module Name: id_reg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module id_reg(
    input wire clk, stage, we_in, flush_in,
    input wire [1:0] rs_alt_in,
    input wire [5:0] opcode_in, 
    input wire [23:0] addr_d12_in,
    input wire [7:0] result_last_in,
    input wire [7:0] imm8_in,
    output reg [1:0] rs_alt,
    output reg [5:0] opcode,
    output reg [15:0] addr_12,
    output reg [7:0] rd,
    output reg [7:0] result_last,
    output reg [7:0] imm8, 
    output reg we, flush2
    );

    always@(posedge clk) begin
        if (stage == 1'b1) begin
            if (!flush_in) begin
                opcode <= opcode_in;
                addr_12 <= addr_d12_in[15:0];
                rd <= addr_d12_in[23:16];
                imm8 <= imm8_in;
                we <= we_in;
                result_last <= result_last_in;
                rs_alt <= rs_alt_in;
                flush2 <= 1'b0;
            end
            else begin
                opcode <= opcode_in;
                addr_12 <= 16'b0;
                rd <= 8'b0;
                imm8 <= 8'b0;
                we <= 1'b0;
                result_last <= 8'b0;
                rs_alt <= 2'b00;
                flush2 <= 1'b1;
            end
        end
    end
endmodule
