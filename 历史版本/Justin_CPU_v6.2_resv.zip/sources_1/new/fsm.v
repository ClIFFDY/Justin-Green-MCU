`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:49:40
// Design Name: 
// Module Name: fsm
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsm(
    input wire clk, rst, frz,
    output reg stage
    );
    
    localparam  
    IDLE = 1'b0, 
    EXE = 1'b1;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            stage <= EXE;
        end
        else if (frz == 1'b1) begin
            stage <= IDLE;
        end
        else begin
            stage <= EXE;
        end
    end

endmodule
