`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:51:25
// Design Name: 
// Module Name: decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder(
    input wire rst,
    input wire [31:0] inst_raw,
    input wire [7:0] result_last_in, rd_last1, rd_last2, 
    input wire [15:0] r12_data_imm,
    input wire [7:0] rd_data_imm,
    input wire [1:0] j_flag,
    output reg [23:0] addr_d12,
    output wire [5:0] opcode,
    output reg [7:0] imm8,
    output reg [7:0] bytmov, result_last,
    output reg [1:0] rs_alt,
    output reg frz, we, flush1
    );
   
    localparam [5:0]
    HALT  = 6'b00_0000,
    ADDI  = 6'b00_0001,
    ADD   = 6'b00_0010,
    SUBI  = 6'b00_0011,
    SUB   = 6'b00_0100,
    AND   = 6'b00_0101,
    OR    = 6'b00_0110,
    XOR   = 6'b00_0111,
    LJAL  = 6'b00_1000,
    RJAL  = 6'b00_1001,
    ANDI  = 6'b00_1010,
    ORI   = 6'b00_1011,
    XORI  = 6'b00_1100,
    SLL   = 6'b00_1101,
    SRL   = 6'b00_1110,
    SLLI  = 6'b00_1111,
    SRLI  = 6'b01_0000,
    SLTU  = 6'b01_0001,
    SLTIU = 6'b01_0010,
    JALR  = 6'b01_0011,
    NOP   = 6'b01_0100,
    //    = 6'b01_0101,
    LBEQ  = 6'b01_0110,
    RBEQ  = 6'b01_0111,
    LBNE  = 6'b01_1000,
    RBNE  = 6'b01_1001,
    LBLTU = 6'b01_1010,
    RBLTU = 6'b01_1011;


    assign opcode = inst_raw[31:26];
    wire [7:0] r1 = inst_raw[15:8];
    wire [7:0] r2 = inst_raw[7:0];
    wire [7:0] r1_data_imm = (r1 == rd_last2)? rd_data_imm : r12_data_imm[15:8];
    wire [7:0] r2_data_imm = (r2 == rd_last2)? rd_data_imm : r12_data_imm[7:0];
    wire [7:0] r1_data_final = (rd_last1 != 8'b0 && r1 == rd_last1)? result_last_in : r1_data_imm;
    wire [7:0] r2_data_final = (rd_last1 != 8'b0 && r2 == rd_last1)? result_last_in : r2_data_imm;


    always @(*) begin
        if (rst) begin
            bytmov = 8'b0;
            addr_d12 = 24'b0;
            imm8 = 8'b0;
            frz = 1'b0;
            we = 1'b0;
            flush1 = 1'b0;
            rs_alt = 2'b00;
        end
        else begin
            bytmov = 8'b0;
            addr_d12 = 24'b0;
            imm8   = 8'b0;
            frz    = 1'b0;
            we     = 1'b0;
            flush1 = 1'b0;
            rs_alt = 2'b00;
            result_last = result_last_in;
            case (inst_raw[31:26])
            LJAL, RJAL: begin
                bytmov = inst_raw[23:16];
                if (!j_flag[1]) flush1 = 1'b1;
            end
            LBEQ, RBEQ: begin
                addr_d12[15:0] = inst_raw[15:0];
                if (r1_data_final == r2_data_final) begin
                    bytmov = inst_raw[23:16];
                    flush1 = 1'b1;                     
                end             
            end
            LBNE, RBNE: begin
                addr_d12[15:0] = inst_raw[15:0];
                if (r1_data_final != r2_data_final) begin
                    bytmov = inst_raw[23:16];
                    flush1 = 1'b1;
                end
            end
            LBLTU, RBLTU: begin
                addr_d12[15:0] = inst_raw[15:0];
                if (r1_data_final < r2_data_final) begin
                    bytmov = inst_raw[23:16];
                    flush1 = 1'b1;
                end
            end
            ADD, SUB, AND, OR, XOR, SLL, SRL, SLTU: begin
                addr_d12 = inst_raw[23:0];
                we = 1'b1;
            end
            ADDI, SUBI, ANDI, ORI, XORI, SLLI, SRLI, SLTIU: begin
                addr_d12[23:8] = inst_raw[23:8];
                imm8 = inst_raw[7:0];
                we = 1'b1;
            end
            JALR: begin
                if (!j_flag[0]) flush1 = 1'b1;
            end
            HALT: begin
                if (!rst) frz = 1'b1;
            end
            NOP: begin
            end
            endcase
            if (we && addr_d12[23:16] != 8'b0) begin
                rs_alt[1] = (r2 == rd_last1)? 1'b1 : 1'b0;
                rs_alt[0] = (r1 == rd_last1)? 1'b1 : 1'b0;
            end
        end
    end
endmodule
