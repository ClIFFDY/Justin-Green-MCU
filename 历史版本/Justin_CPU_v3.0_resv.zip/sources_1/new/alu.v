`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: alu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu(
    input wire [7:0] a, b, imm8,
    input wire [3:0] opr, 
    output reg [7:0] result
    );

    localparam [3:0] 
    ADDI = 4'b0001,
    ADD  = 4'b0010,
    SUBI = 4'b0011,
    SUB  = 4'b0100,
    AND  = 4'b0101,
    OR   = 4'b0110,
    XOR  = 4'b0111;
    
    always @(*) begin
        case(opr)
        ADDI: result = a + imm8;
        ADD: result = a + b;
        SUBI:result = a - imm8;
        SUB: result = a - b;
        AND: result = a & b;
        OR: result = a | b;
        XOR: result = a ^ b;
        default: result = 8'b0;
        endcase
    end

endmodule
