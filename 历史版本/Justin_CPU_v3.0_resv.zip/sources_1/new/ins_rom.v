`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: ins_rom
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ins_rom(
    input wire [7:0] addr,
    output wire [7:0] inst
    );

    reg[7:0] mem [0:255];

    initial begin
        mem[0] = 8'b0001_0001; 
        mem[1] = 8'b0010_0001;

        mem[2] = 8'b0001_0010;
        mem[3] = 8'b0011_0010;

        mem[4] = 8'b0010_0001;
        mem[5] = 8'b0010_0010;

        mem[6]  = 8'b0001_0001; 
        mem[7]  = 8'b0010_0001;

        mem[8]  = 8'b0001_0010;
        mem[9]  = 8'b0011_0010;

        mem[10] = 8'b0010_0001;
        mem[11] = 8'b0010_0010;

        mem[12] = 8'b1000_0010;
        mem[13] = 8'b0000101_1;

        mem[14] = 8'b0001_0001;
        mem[15] = 8'b0001_0001;

        mem[16] = 8'b0000_0000;
        mem[17] = 8'b0000_0000;

        mem[18] = 8'b0010_0001;
        mem[19] = 8'b0010_0010;
    end

    assign inst = mem[addr];
endmodule

// HALT = 4'b0000;
// ADDI = 4'b0001;
// ADD = 4'b0010;
// SUBI = 4'b0011
// SUB = 4'b0100;
// AND = 4'b0101;
// OR = 4'b0110;
// XOR = 4'b0111;
// LJMP = 4'b1000;
// RJMP = 4'b1001;