`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:51:25
// Design Name: 
// Module Name: decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module decoder(
    input wire clk, rst,
    input wire [2:0] stage,
    input wire [7:0] inst_raw,
    output reg [3:0] addr1, addr2, addr3, 
    output reg [3:0] opcode, j_insnum,
    output reg [7:0] imm8,
    output reg [7:0] jmp_mes,
    output reg frz
    );
   
    localparam [3:0] 
    HALT = 4'b0000,
    ADDI = 4'b0001,
    ADD  = 4'b0010,
    SUBI = 4'b0011,
    SUB  = 4'b0100,
    AND  = 4'b0101,
    OR   = 4'b0110,
    XOR  = 4'b0111,
    LJMP = 4'b1000,
    RJMP = 4'b1001;

    localparam [2:0] 
    IDLE = 3'b000, 
    FET1 = 3'b001, 
    FET2 = 3'b010, 
    OPR  = 3'b011, 
    WRT  = 3'b100;

    always@(posedge clk or posedge rst) begin
        if (rst) begin
            frz <= 1'b0;
            opcode <= 4'b0001;
            addr1 <= 4'b0;
            addr2 <= 4'b0;
            addr3 <= 4'b0;
        end
        else begin
            if (stage == FET1) begin
                opcode <= inst_raw[7:4];
                if (inst_raw[7:4] == LJMP || inst_raw[7:4] == RJMP) begin 
                    addr1 <= 4'b0;
                    j_insnum <= inst_raw[3:0];
                end
                else begin
                    addr1 <= inst_raw[3:0];
                end
            end
            else if (stage == FET2) begin
                case (opcode)
                    ADDI, SUBI: begin
                        addr2 <= 4'b0;
                        imm8 <= {4'b0, inst_raw[7:4]};
                        addr3 <= inst_raw[3:0];
                    end
                    LJMP, RJMP: begin
                        addr2 <= 4'b0;
                        addr3 <= 4'b0;
                        imm8 <= 8'b0;
                        jmp_mes <= inst_raw;
                    end
                    HALT: begin
                        frz <= 1'b1;
                        addr2 <= 4'b0;
                        addr3 <= 4'b0;
                        imm8 <= 8'b0;
                    end
                    default: begin
                        addr2 <= inst_raw[7:4];
                        imm8 <= 8'b0;
                        addr3 <= inst_raw[3:0];
                    end 
                endcase
            end
        end
    end
endmodule
