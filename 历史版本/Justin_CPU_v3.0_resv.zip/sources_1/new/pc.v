`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/09 22:05:38
// Design Name: 
// Module Name: pc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pc(
    input wire clk, rst, 
    input wire [2:0] stage,
    input wire [3:0] opcode, j_insnum,
    input wire [7:0] jmp_mes,
    output reg [7:0] addr
    );

    reg [7:0] nextadd;
    reg [3:0] insnum;
    reg jmped;

    localparam [2:0] 
    IDLE = 3'b000, 
    FET1 = 3'b001, 
    FET2 = 3'b010, 
    OPR  = 3'b011, 
    WRT  = 3'b100;
    
    always@(posedge clk or posedge rst) begin
        if (rst) begin 
            addr <= 8'd0;
            insnum <= 4'b0;
            jmped <= 1'b0;
        end
        else if (stage == FET1 || stage == FET2) begin
            addr <= addr + 1;
        end
        else if (stage == OPR) begin
            if (opcode == 4'b1000 || opcode == 4'b1001) begin
                insnum <= j_insnum + 1;
                nextadd <= addr;
                jmped <= 1'b1;
                case (opcode[0])
                1'b0: addr <= addr - ({1'b0, jmp_mes[7:1]} + {1'b0, jmp_mes[7:1]});
                1'b1: addr <= addr + ({1'b0, jmp_mes[7:1]} + {1'b0, jmp_mes[7:1]});
                default: addr <= addr + 2;
                endcase
            end
        end
        else if (stage == WRT) begin
            case (insnum)
            4'b0: begin 
                if(jmp_mes[0] == 1'b1 && jmped == 1'b1) begin
                   addr <= nextadd;
                   jmped <= 1'b0; 
                end 
            end
            default: insnum <= insnum - 1;
            endcase
        end
    end
endmodule
