`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 12:49:40
// Design Name: 
// Module Name: fsm
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fsm(
    input wire clk, rst, frz,
    output reg [2:0] stage,
    output reg we
    );
    
    localparam [2:0] 
    IDLE = 3'b000, 
    FET1 = 3'b001, 
    FET2 = 3'b010, 
    OPR  = 3'b011, 
    WRT  = 3'b100;

    always @(posedge clk or posedge rst) begin
        if (rst) begin 
            stage <= FET1;
            we <= 1'b1;
        end
        else begin
            case (stage)
            IDLE: begin
                if (!frz) begin
                    we <= 1'b1;
                    stage <= FET1;   
                end 
            end
            FET1: stage <= FET2;
            FET2: stage <= OPR;
            OPR: begin 
                if (frz) begin 
                    stage <= IDLE;
                    we <= 1'b0;
                end
                else stage <= WRT;
            end
            WRT: stage <= FET1;
            default: stage <= IDLE;
            endcase
        end
    end
endmodule
