`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 00:01:51
// Design Name: 
// Module Name: single_cpu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module single_cpu_top(
    input wire clk, rst,
    output wire [7:0] alu_res
    );

    wire [7:0] pc_addr;
    wire [7:0] inst;
    wire [7:0] rs1_data, rs2_data, imm_temp, imm8;
    wire [7:0] jmp_mes;
    wire [3:0] op_temp, opcode, insnum;
    wire [3:0] r1_temp, r2_temp, wr_temp;
    wire [3:0] addr1, addr2, waddr;
    wire we, frz;
    wire [2:0] stage;

    fsm u_fsm(
        .clk(clk),
        .rst(rst),
        .frz(frz),
        .stage(stage),
        .we(we)
    );

    pc u_pc(
        .clk(clk),
        .rst(rst),
        .stage(stage),
        .opcode(op_temp),
        .addr(pc_addr),
        .jmp_mes(jmp_mes),
        .j_insnum(insnum)
        );

    ins_rom u_ins_rom(
        .addr(pc_addr), 
        .inst(inst)
        );

    decoder u_decoder(
        .clk(clk),
        .rst(rst),
        .stage(stage),
        .inst_raw(inst),
        .addr1(r1_temp),
        .addr2(r2_temp),
        .addr3(wr_temp),
        .opcode(op_temp),
        .j_insnum(insnum),
        .imm8(imm_temp),
        .jmp_mes(jmp_mes),
        .frz(frz)
        );

    ir u_ir(
        .clk(clk),
        .stage(stage),
        .op_in(op_temp),
        .addr1_in(r1_temp),
        .addr2_in(r2_temp),
        .addr3_in(wr_temp),
        .imm_raw(imm_temp),
        .opcode(opcode),
        .addr1(addr1),
        .addr2(addr2),
        .imm8(imm8),
        .waddr(waddr)
    );

    reg_f u_reg_f(
        .clk(clk), 
        .we(we), 
        .stage(stage),
        .addr1(addr1),
        .addr2(addr2),
        .waddr(waddr),
        .rs1_data(rs1_data),
        .rs2_data(rs2_data),
        .wdata(alu_res)
        );

    alu u_alu(
        .a(rs1_data),
        .b(rs2_data),
        .imm8(imm8),
        .opr(opcode),
        .result(alu_res)
        );

endmodule

