`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 02:43:51
// Design Name: 
// Module Name: ir
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ir(
    input wire clk,
    input wire [2:0] stage,
    input wire [3:0] op_in, addr1_in, addr2_in, addr3_in,
    input wire [7:0] imm_raw,
    output reg [3:0] opcode, addr1, addr2, waddr,
    output reg [7:0] imm8
    );

    always@(posedge clk) begin
        if (stage == 3'b011) begin
            opcode <= op_in;
            addr1 <= addr1_in;
            addr2 <= addr2_in;
            imm8 <= imm_raw;
            waddr <= addr3_in;
        end
    end
endmodule
