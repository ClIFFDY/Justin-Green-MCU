`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/10 00:01:51
// Design Name: 
// Module Name: single_cpu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module single_cpu_top(
    input wire clk, rst
    );

    wire stage;
    wire [7:0] pc_addr;
    wire [31:0] inst_raw1, inst_raw2;
    wire [1:0] inst_num;
    wire [5:0] op_temp, opcode;
    wire [23:0] rd12, rr12_data;
    wire [15:0] ab_raw;
    wire [12:0] addr_ram;
    wire [7:0] rd_temp, rd;
    wire [7:0] rd_data, rr_rdata, rr_wdata, imm8_temp, imm8;
    wire [7:0] bytmov;
    wire [7:0] ra_fo, ra_ba;
    wire [7:0] result, result_last1, result_last2;
    wire [1:0] rs_alt1, rs_alt2, jmpflg, j_flag, ram_flag1, ram_flag2;
    wire we_temp1, we_temp2, we;
    wire frz, flush1, flush2;

    fsm u_fsm(
        .clk(clk),
        .rst(rst),
        .frz(frz),
        //
        .stage(stage)
    );

    pc u_pc(
        .clk(clk),
        .rst(rst),
        .frz(frz),
        .stage(stage),
        .j_flag(j_flag),
        .inst_num(inst_num),
        .op_raw(op_temp),
        .bytmov(bytmov),
        .ra_in(ra_ba),
        //
        .pc_addr(pc_addr),
        .ra(ra_fo),
        .jmpflg(jmpflg)
        );

    ins_rom u_ins_rom(
        .addr(pc_addr),
        //
        .inst_raw(inst_raw1),
        .inst_num(inst_num)
        );
    
    if_reg u_if_reg(
        .clk(clk),
        .flush_raw(flush1),
        .stage(stage),
        .rst(rst),
        .inst_raw_in(inst_raw1),
        //
        .inst_raw(inst_raw2)
    );

    decoder u_decoder(
        .rst(rst),
        .inst_raw(inst_raw2),
        .result_last_in(result),
        .rd_last1(rd_temp),
        .rd_last2(rd),
        .rr12_data(rr12_data),
        .rd_data(rd_data),
        .j_flag(j_flag),
        //
        .addr_dr12(rd12),
        .addr_ram(addr_ram),
        .opcode(op_temp),
        .rr_data_final(rr_wdata),
        .imm8(imm8_temp),
        .bytmov(bytmov),
        .result_last(result_last1),
        .rs_alt(rs_alt1),
        .ram_flag(ram_flag1),
        .frz(frz),
        .we(we_temp1),
        .flush1(flush1)
        );

    id_reg u_id_reg(
        .clk(clk),
        .stage(stage),
        .we_in(we_temp1),
        .flush_in(flush1),
        .rs_alt_in(rs_alt1),
        .ram_flag_in(ram_flag1),
        .opcode_in(op_temp),
        .rd_in(rd12[23:16]),
        .result_last_in(result_last1),
        .imm8_in(imm8_temp),
        .ab_raw_in(rr12_data[15:0]),
        //
        .rs_alt(rs_alt2),
        .ram_flag(ram_flag2),
        .opcode(opcode),
        .ab_raw(ab_raw),
        .rd(rd_temp),
        .imm8(imm8),
        .result_last(result_last2),
        .we(we_temp2),
        .flush2(flush2)
    );

    alu u_alu(
        .rs_alt(rs_alt2),
        .ram_flag_in(ram_flag2),
        .ab_raw(ab_raw),
        .ram_data(rr_rdata),
        .result_last(result_last2),
        .imm8(imm8),
        .opcode(opcode),
        //
        .result(result)
        );

    wr_reg u_wr_reg(
        .clk(clk),
        .we_in(we_temp2),
        .stage(stage),
        .flush2(flush2),
        .rst(rst),
        .result_in(result),
        .rd_in(rd_temp),
        //
        .rd_data(rd_data),
        .rd(rd),
        .we(we)
    );
    
    reg_f u_reg_f(
        .clk(clk), 
        .we(we), 
        .jmpflg(jmpflg),
        .addr_r12(rd12),
        .rd(rd),
        .ra_in(ra_fo),
        .rd_data(rd_data),
        //
        .j_flag(j_flag),
        .ra(ra_ba),
        .rr12_data(rr12_data)
        );

        data_ram u_data_ram(
        .clk(clk),
        .we_ram(ram_flag1[0]),
        .addr_ram(addr_ram),
        .wdata(rr_wdata),
        //
        .rdata(rr_rdata)
        );
    
endmodule

