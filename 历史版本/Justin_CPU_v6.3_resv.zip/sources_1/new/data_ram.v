`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/08/12 20:40:27
// Design Name: 
// Module Name: data_ram
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module data_ram(
    input wire clk, we_ram,
    input wire [12:0] addr_ram,
    input wire [7:0] wdata,
    output reg [7:0] rdata
    );

    (* ram_style = "block" *) reg [7:0] mem [0:8191];

    integer i;
    initial begin
        for (i = 0; i < 8192; i = i + 1) mem[i] = 8'b0;
    end

    always @(posedge clk) begin
        if (we_ram) begin
            mem[addr_ram] <= wdata; 
        end
        rdata <= mem[addr_ram]; 
    end
endmodule

