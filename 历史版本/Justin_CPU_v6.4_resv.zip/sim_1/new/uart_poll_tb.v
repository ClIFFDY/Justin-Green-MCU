`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// CPU→UART 集成测试：busy 轮询 + SB 到 0x2000 发送
//   - ins_rom.hex 程序：3 次"LBNE r255,r0 轮询 → SB r1,0x2000 发送"
//   - 本 tb 内建 UART 接收模型，按 MCNT 周期逐 bit 采样校验帧（start/8数据/stop）
//   - CPU HALT 后等最后一帧收完，比对应收到 'H'(0x48) 'i'(0x69) '!'(0x21)
// 运行：cd project_self-try.srcs && /d/iverilog/bin/iverilog -g2012 -o uart_sys_sim \
//          sources_1/new/*.v sim_1/new/uart_poll_tb.v && /d/iverilog/bin/vvp uart_sys_sim
//////////////////////////////////////////////////////////////////////////////////

module uart_poll_tb;

    reg clk = 0, rst = 1;
    always #10 clk = ~clk;   // 20ns = 50MHz（与 timing.xdc 一致）

    wire tx;
    single_cpu_top u_single_cpu_top(
        .clk(clk),
        .rst(rst),
        .tx(tx)
    );

    localparam MCNT = 50000000 / 115200;   // 434 拍/bit

    // ===== UART 接收模型：检测起始位下降沿，逐 bit 中点采样 =====
    reg tx_d = 1'b1;
    reg rxing = 0;
    reg [15:0] s_cnt = 0;
    reg [3:0]  nbit = 0;      // 采样序号 0=start 1..8=data 9=stop
    reg [7:0]  rbyte = 0;
    reg [7:0]  rx_buf [0:15];
    integer rx_cnt = 0;
    integer rx_err = 0;

    always @(posedge clk) begin
        tx_d <= tx;
        if (rxing) begin
            s_cnt <= s_cnt + 1;
            if (s_cnt == MCNT/2 - 1 + nbit * MCNT) begin
                if (nbit == 0) begin
                    if (tx !== 1'b0) begin
                        $display("FAIL @%0t 起始位应=0 实际=%b", $time, tx);
                        rx_err = rx_err + 1;
                    end
                    nbit <= nbit + 1;
                end
                else if (nbit <= 8) begin
                    rbyte[nbit - 1] <= tx;
                    nbit <= nbit + 1;
                end
                else begin
                    if (tx !== 1'b1) begin
                        $display("FAIL @%0t 停止位应=1 实际=%b", $time, tx);
                        rx_err = rx_err + 1;
                    end
                    rx_buf[rx_cnt] <= rbyte;
                    rx_cnt <= rx_cnt + 1;
                    rxing <= 0;
                    $display("RX @%0t 0x%02x = %c", $time, rbyte, rbyte);
                end
            end
        end
        else if (tx_d && !tx) begin   // 起始位下降沿
            rxing <= 1;
            s_cnt <= 0;
            nbit <= 0;
            rbyte <= 0;
        end
    end
    // ===== 接收模型结束 =====

    // 载入指令到 ins_rom
    initial begin
        $readmemh("E:/Vivado_Projects/project_self-try/project_self-try.srcs/ins_rom.hex", u_single_cpu_top.u_ins_rom.mem);
    end

    // 复位：20ns 后放开
    initial begin
        rst = 1;
        #20
        rst = 0;
    end

    reg halted = 0;
    reg checked = 0;

    // 检测 CPU HALT（stage 掉 0）
    always @(posedge clk) begin
        if (!rst && !halted && u_single_cpu_top.stage == 1'b0)
            halted <= 1'b1;
    end

    // HALT 后最后一帧可能还在发，等 rx_cnt>=3 再比对
    always @(posedge clk) begin
        if (halted && !checked && rx_cnt >= 3) begin
            checked <= 1'b1;
            if (rx_err == 0)
                $display("PASS: 3 帧全部有效（起始/数据/停止位均正确）");
            else
                $display("FAIL: %0d 处帧错误", rx_err);
            if (rx_buf[0] == 8'h48 && rx_buf[1] == 8'h69 && rx_buf[2] == 8'h21)
                $display("PASS: 收到 'H''i''!' 顺序正确");
            else
                $display("FAIL: 字节内容/顺序错误 %02x %02x %02x", rx_buf[0], rx_buf[1], rx_buf[2]);
            $display("===== %s =====", (rx_err == 0 && rx_buf[0] == 8'h48 && rx_buf[1] == 8'h69 && rx_buf[2] == 8'h21) ? "ALL TESTS PASSED" : "ERRORS");
            $finish;
        end
    end

    // 兜底超时：3 帧约 26us（20ns 时钟），1ms 足够
    initial begin
        #1000000
        $display("TIMEOUT: 未收到完整 3 字节（halted=%b rx_cnt=%0d）", halted, rx_cnt);
        $finish;
    end

endmodule
